/******************************************************************************

  Create settings table.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/conf/settings.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE TABLE util.settings(   section       VARCHAR2(100)
                             ,name          VARCHAR2(100)
                             ,value         VARCHAR2(300)
                             ,val_type      VARCHAR2(300) )
PCTFREE 20 PCTUSED 85
/

ALTER TABLE util.settings
  ADD CONSTRAINT pk_settings
  PRIMARY KEY ( section, name )
/

ALTER TABLE util.settings
  ADD CONSTRAINT chk_settings_type
  CHECK ( val_type  IN ('STRING', 'NUMBER', 'BOOLEAN') )
/


CREATE OR REPLACE TRIGGER util.tbiu_settings
BEFORE INSERT OR UPDATE ON util.settings
FOR EACH ROW
/**

  Before insert or update ensure the setting name is stored in lower case
  so case sensitivity is not an issue.

*/
BEGIN
  :new.name := LOWER(:new.name);
END;
/

show error

COMMENT ON TABLE util.settings IS 'Configuration settings table utilised by util_conf internally. Please note that this table is managed by util_conf and should not be populated manually.';
COMMENT ON COLUMN util.settings.section IS 'The configuration section.';
COMMENT ON COLUMN util.settings.name IS 'The name of the setting.';
COMMENT ON COLUMN util.settings.value IS 'The configuration value of the setting.';
COMMENT ON COLUMN util.settings.val_type IS 'The type of the value setting used to check when specific accessors are used.';
