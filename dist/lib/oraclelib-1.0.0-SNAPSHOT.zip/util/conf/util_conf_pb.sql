/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_conf
pro

CREATE OR REPLACE PACKAGE BODY util.util_conf
IS
/******************************************************************************

  Application Mangement and Support Package.

  This package provides essentail application management features such as
  determining runtime deployment, system and application wide settings features.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/conf/util_conf_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  11/02/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  DEFAULT_SECTION CONSTANT settings.section%TYPE := 'default';

  lgr Logger := Logger.get_logger('core.configuration');

  /*{%skip}**********************************************************************
   *
   *
   *  A collection of procedures to manage settings.
   *  These settings will be written to the settings table.
   *
   *
   ******************************************************************************/

  -- Set a string value.
  PROCEDURE setval( p_section     IN settings.section%TYPE
                   ,p_name        IN settings.name%TYPE
                   ,p_value       IN settings.value%TYPE
                   ,p_type        IN settings.val_type%TYPE DEFAULT 'STRING')
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- validate the property name
    IF p_name IS NULL THEN
      util_exception.raise('invalid_argument', 'Empty setting name', 'you must provide a setting name.');
    END IF;

    IF lgr.is_trace THEN
      lgr.trace('setting section [%s] name[%s] value[%s]');
    END IF;
    -- merge property into the settings table.
    MERGE INTO settings s
    USING ( SELECT  NVL(p_section, DEFAULT_SECTION)   AS s
                   ,p_name                            AS n
                   ,p_value                           AS v
                   ,p_type                            AS t
            FROM dual ) d
    ON (s.section = d.s AND s.name = d.n)
    WHEN MATCHED THEN
      UPDATE SET s.value = d.v, s.val_type = d.t
    WHEN NOT MATCHED THEN
      INSERT (section, name, value, val_type)
      VALUES (d.s, d.n, d.v, d.t);
    COMMIT;
  END;

  -- Set a string value.
  PROCEDURE set( p_name        IN settings.name%TYPE
                ,p_value       IN settings.value%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL)
  IS
  BEGIN
    util_conf.setval(p_section, p_name, p_value, 'STRING');
  END;


  -- Set a numeric value.
  PROCEDURE set( p_name        IN settings.name%TYPE
                ,p_value       IN NUMBER
                ,p_section     IN settings.section%TYPE DEFAULT NULL)
  IS
  BEGIN
    util_conf.setval(p_section, p_name, TO_CHAR(p_value), 'NUMBER');
  END;


  -- Set a boolean value.
  PROCEDURE set( p_name        IN settings.name%TYPE
                ,p_value       IN BOOLEAN
                ,p_section     IN settings.section%TYPE DEFAULT NULL)
  IS
  BEGIN
    util_conf.setval(p_section, p_name, util_string.bool_to_char(p_value), 'BOOLEAN');
  END;


  /*

    Private function to get the actual setting value.

  */
  FUNCTION getval( p_section     IN settings.section%TYPE
                  ,p_name        IN settings.name%TYPE) RETURN settings.value%TYPE
  IS
    l_value settings.value%TYPE;
  BEGIN
    -- validate the property name
    IF p_name IS NULL THEN
      util_exception.raise('invalid_argument', 'Empty setting name', 'you must provide a setting name.');
    END IF;
    -- try to get the setting within the section specified
    SELECT s.value
    INTO   l_value
    FROM   settings s
    WHERE  s.section   = NVL(p_section, DEFAULT_SECTION)
    AND    s.name      = p_name;
    RETURN l_value;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- try to retrieve setting from generic section if that fails raise property not found.
      BEGIN
        SELECT s.value
        INTO   l_value
        FROM   settings s
        WHERE  s.section   = DEFAULT_SECTION
        AND    s.name      = p_name;
        RETURN l_value;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        -- raise no setting
        IF p_section IS NOT NULL THEN
          util_exception.raise('property_not_found', p_name || ' in section ' || p_section);
        ELSE
          util_exception.raise('property_not_found', p_name);
        END IF;
      END;
  END;


  -- Get a string setting. This is the default type of how settings are stored.
  FUNCTION get( p_name        IN settings.name%TYPE
               ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN settings.value%TYPE
  IS
  BEGIN
    RETURN getval(p_section, p_name);
  END;


  -- Get a string setting.
  FUNCTION gets( p_name        IN settings.name%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN settings.value%TYPE
  IS
  BEGIN
    RETURN getval(p_section, p_name);
  END;


  -- Get a numeric setting.
  FUNCTION getn( p_name        IN settings.name%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN NUMBER
  IS
    l_value settings.value%TYPE;
  BEGIN
    l_value := getval(p_section, p_name);
    -- TODO: check if datatype is NUMBER, if not raise error
    RETURN TO_NUMBER(l_value);
  END;


  -- Get a boolean setting.
  FUNCTION getb( p_name        IN settings.name%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN BOOLEAN
  IS
    l_value settings.value%TYPE;
  BEGIN
    l_value := getval(p_section, p_name);
    -- TODO: check if datatype is BOOLEAN, if not raise error
    RETURN util_string.to_bool(l_value);
  END;


  /*{%skip}**********************************************************************
   *
   *
   *  A collection of procedures to determine runtime deployment of the applications.
   *
   *
   ******************************************************************************/

  -- Get the database instance name logged into.
  FUNCTION get_instance_name RETURN VARCHAR2
  IS
    l_name v$instance.instance_name%TYPE;
    -- l_name VARCHAR2(100);
  BEGIN

    SELECT lower(instance_name)
    INTO l_name
    FROM v$instance
    WHERE ROWNUM = 1;

    RETURN l_name;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- TODO: need to log this with app support since instances must have changed !
      RAISE;
  END;


  /*{%skip}**********************************************************************
   *
   *
   *  Session specific stuff.
   *
   *
   ******************************************************************************/

  -- Get the os user of the currently logged on user
  FUNCTION get_os_username RETURN VARCHAR2
  IS
    l_user VARCHAR2(100) := 'unknown';
  BEGIN

    SELECT s.osuser
    INTO   l_user
    FROM   v$mystat ms
          ,v$session s
    WHERE  ms.sid = s.sid
    AND    s.type='USER'
    AND    ROWNUM = 1;

    RETURN l_user;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN l_user;
  END;

END util_conf;
/

show error
