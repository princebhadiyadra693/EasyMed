/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_conf
pro

CREATE OR REPLACE PACKAGE util.util_conf
IS
/******************************************************************************

  Configuration Management Package.

  This package provides essentail configuration management features such as
  managing settings, determining database and session specific information.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/conf/util_conf_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  11/02/2004  Bertram        Initial Version                         <br>

******************************************************************************/


  /*{%skip}**********************************************************************
   *
   *
   *  A collection of procedures to manage settings.
   *
   *
   ******************************************************************************/

  /**

    Set a string value.

    %Note: The setting is updated if it exitsts or if the setting does not exist
           then it will be created.

    %param p_name         The setting name to add or update.
    %param p_value        The string value to set.
    %param p_section      The section to add the setting to. If left blank
                          it is assumed to be added to the default section.

  */
  PROCEDURE set( p_name        IN settings.name%TYPE
                ,p_value       IN settings.value%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL);


  /**

    Set a numeric value.

    %Note: The setting is updated if it exitsts or if the setting does not exist
           then it will be created.

    %param p_name         The setting name to add or update.
    %param p_value        The numeric value to set.
    %param p_section      The section to add the setting to. If left blank
                          it is assumed to be added to the default section.

  */
  PROCEDURE set( p_name        IN settings.name%TYPE
                ,p_value       IN NUMBER
                ,p_section     IN settings.section%TYPE DEFAULT NULL);

  /**

    Set a boolean value.

    %Note: The setting is updated if it exitsts or if the setting does not exist
           then it will be created.

    %param p_name         The setting name to add or update.
    %param p_value        The boolean value to set.
    %param p_section      The section to add the setting to. If left blank
                          it is assumed to be added to the default section.

  */
  PROCEDURE set( p_name        IN settings.name%TYPE
                ,p_value       IN BOOLEAN
                ,p_section     IN settings.section%TYPE DEFAULT NULL);



  /**

    Get a string setting. This is the default type of how settings are stored.

    %param p_name     The setting name.
    %param p_section  The section to which the setting belongs to. If left blank
                      it is assumed to be retrieved from the default section.

    %return           The setting value of tpe string or raises error if not defined.

    %raises           property_not_found exception when setting is not found in the
                      specified section nor the default section.

  */
  FUNCTION get( p_name        IN settings.name%TYPE
               ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN settings.value%TYPE;


  /**

    Get a string setting.

    Note: This procedure follows the convention of get[type],
          where type is n for NUMERIC, s for STRING etc.

    %param p_name     The setting name.
    %param p_section  The section to which the setting belongs to. If left blank
                      it is assumed to be retrieved from the default section.

    %return           The setting value with the type specified by get[type] or raises
                      error if not defined.

    %raises           property_not_found exception when setting is not found in the
                      specified section nor the default section.

  */
  FUNCTION gets( p_name        IN settings.name%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN settings.value%TYPE;

  /**

    Get a number setting.

    Note: This procedure follows the convention of get[type],
          where type is n for NUMERIC, s for STRING etc.

    %param p_name     The setting name within the domain.
    %param p_section  The section to which the setting belongs to. If left blank
                      it is assumed to be retrieved from the default section.

    %return           The setting value with the type specified by get[type] or raises
                      error if not defined.

    %raises           property_not_found exception when setting is not found in the
                      specified section nor the default section.

  */
  FUNCTION getn( p_name        IN settings.name%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN NUMBER;

  /**

    Get a boolean setting.

    Note: This procedure follows the convention of get[type],
          where type is n for NUMERIC, s for STRING etc.

    %param p_name     The setting name within the domain.
    %param p_section  The section to which the setting belongs to. If left blank
                      it is assumed to be retrieved from the default section.

    %return           The setting value with the type specified by get[type] or raises
                      error if not defined.

    %raises           property_not_found exception when setting is not found in the
                      specified section nor the default section.

  */
  FUNCTION getb( p_name        IN settings.name%TYPE
                ,p_section     IN settings.section%TYPE DEFAULT NULL) RETURN BOOLEAN;


  /*{%skip}**********************************************************************
   *
   *
   *  A collection of procedures to determine runtime deployment of the applications.
   *
   *
   ******************************************************************************/

  /**

    Get the database instance name logged into.

    %return     The name if the database instance.

  */
  FUNCTION get_instance_name RETURN VARCHAR2;


  /*{%skip}**********************************************************************
   *
   *
   *  Session specific stuff.
   *
   *
   ******************************************************************************/

  /*

    Get the os user of the currently logged on user.

    %return     The os user that is currently logged on.

  */

  FUNCTION get_os_username RETURN VARCHAR2;


END util_conf;
/

show error
