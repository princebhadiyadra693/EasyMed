/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Function sprintf
pro
CREATE OR REPLACE FUNCTION util.sprintf( p_string IN VARCHAR2
                                        ,p_arg1   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg2   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg3   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg4   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg5   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg6   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg7   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg8   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg9   IN VARCHAR2 DEFAULT NULL
                                        ,p_arg10  IN VARCHAR2 DEFAULT NULL
                                        ,p_arg11  IN VARCHAR2 DEFAULT NULL
                                        ,p_arg12  IN VARCHAR2 DEFAULT NULL
                                        ,p_arg13  IN VARCHAR2 DEFAULT NULL
                                        ,p_arg14  IN VARCHAR2 DEFAULT NULL
                                        ,p_arg15  IN VARCHAR2 DEFAULT NULL) RETURN VARCHAR2
IS
/******************************************************************************

  Wrapper function for util_string.sprintf

  %Script:    util_sprintf.sql

  %RunAs:     util or DBA

  %Version    $Id: util_sprintf.sql 1 2008-12-20 10:37:20Z niels-bertram $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  26/10/2008  Bertram        Initial Version                         <br>

******************************************************************************/
BEGIN

  RETURN util_string.sprintf( p_string
                            ,p_arg1
                            ,p_arg2
                            ,p_arg3
                            ,p_arg4
                            ,p_arg5
                            ,p_arg6
                            ,p_arg7
                            ,p_arg8
                            ,p_arg9
                            ,p_arg10
                            ,p_arg11
                            ,p_arg12
                            ,p_arg13
                            ,p_arg14
                            ,p_arg15);
END;
/

show error
