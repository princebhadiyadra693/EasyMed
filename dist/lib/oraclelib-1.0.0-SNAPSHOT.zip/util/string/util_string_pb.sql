/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_string
pro
CREATE OR REPLACE PACKAGE BODY util.util_string AS
/******************************************************************************

  Utility package to manage string related functionality.

  This package provides string functions such as generating hex strings from
  numbers.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/util_string_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  29/01/2004  Bertram        Initial Version                         <br>
   1.1  23/10/2008  Bertram        Made sprintf first arg optional.        <br>

******************************************************************************/

  -- string formatting like C sprintf but only currently for strings only.
  FUNCTION sprintf( p_string IN VARCHAR2
                   ,p_arg1   IN VARCHAR2 DEFAULT NULL
                   ,p_arg2   IN VARCHAR2 DEFAULT NULL
                   ,p_arg3   IN VARCHAR2 DEFAULT NULL
                   ,p_arg4   IN VARCHAR2 DEFAULT NULL
                   ,p_arg5   IN VARCHAR2 DEFAULT NULL
                   ,p_arg6   IN VARCHAR2 DEFAULT NULL
                   ,p_arg7   IN VARCHAR2 DEFAULT NULL
                   ,p_arg8   IN VARCHAR2 DEFAULT NULL
                   ,p_arg9   IN VARCHAR2 DEFAULT NULL
                   ,p_arg10  IN VARCHAR2 DEFAULT NULL
                   ,p_arg11  IN VARCHAR2 DEFAULT NULL
                   ,p_arg12  IN VARCHAR2 DEFAULT NULL
                   ,p_arg13  IN VARCHAR2 DEFAULT NULL
                   ,p_arg14  IN VARCHAR2 DEFAULT NULL
                   ,p_arg15  IN VARCHAR2 DEFAULT NULL) RETURN VARCHAR2
  IS
    i NUMBER := 0;
    l_result VARCHAR2(32767) := p_string;
    l_more_args BOOLEAN := TRUE;
    l_occur VARCHAR2(10) := '%s'; -- TODO: expand to work with %d, %t and the like too
  BEGIN
    WHILE l_more_args
    LOOP
      i := i + 1;
      IF i = 1 AND p_arg1 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg1);
        l_more_args := p_arg2 IS NOT NULL;
      ELSIF i = 2 AND p_arg2 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg2);
        l_more_args := p_arg3 IS NOT NULL;
      ELSIF i = 3 AND p_arg3 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg3);
        l_more_args := p_arg4 IS NOT NULL;
      ELSIF i = 4 AND p_arg4 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg4);
        l_more_args := p_arg5 IS NOT NULL;
      ELSIF i = 5 AND p_arg5 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg5);
        l_more_args := p_arg6 IS NOT NULL;
      ELSIF i = 6 AND p_arg6 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg6);
        l_more_args := p_arg7 IS NOT NULL;
      ELSIF i = 7 AND p_arg7 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg7);
        l_more_args := p_arg8 IS NOT NULL;
      ELSIF i = 8 AND p_arg8 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg8);
        l_more_args := p_arg9 IS NOT NULL;
      ELSIF i = 9 AND p_arg9 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg9);
        l_more_args := p_arg10 IS NOT NULL;
      ELSIF i = 10 AND p_arg10 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg10);
        l_more_args := p_arg11 IS NOT NULL;
      ELSIF i = 11 AND p_arg11 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg11);
        l_more_args := p_arg12 IS NOT NULL;
      ELSIF i = 12 AND p_arg12 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg12);
        l_more_args := p_arg13 IS NOT NULL;
      ELSIF i = 13 AND p_arg13 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg13);
        l_more_args := p_arg14 IS NOT NULL;
      ELSIF i = 14 AND p_arg14 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg14);
        l_more_args := p_arg15 IS NOT NULL;
      ELSIF i = 15 AND p_arg15 IS NOT NULL THEN
        l_result := replace_once(l_result, l_occur, p_arg15);
        l_more_args := FALSE;
      ELSE
        l_more_args := FALSE;
      END IF;
    END LOOP;
    RETURN l_result;
  END sprintf;


  -- replaces only the first occurence of a string with the argument provided.
  FUNCTION replace_once( p_string  IN VARCHAR2
                        ,p_occur   IN VARCHAR2
                        ,p_arg     IN VARCHAR2) RETURN VARCHAR2
  IS
    l_idx NUMBER := 0;
  BEGIN
    l_idx := INSTR(p_string, p_occur, 1);
    IF l_idx <= 0 THEN
      -- REVIEW: nothing to replace just ignore?
      RETURN p_string;
    ELSE
      RETURN SUBSTR(p_string,0, l_idx - 1) || p_arg || SUBSTR(p_string, l_idx + length(p_occur));
    END IF;
  END replace_once;


  -- Base64 encodes a string.
  FUNCTION base64_encode( p_string IN VARCHAR2) RETURN VARCHAR2
  IS
  BEGIN
   -- TODO: should validate the string in case utl_raw falls over? 
   RETURN utl_raw.cast_to_varchar2( utl_encode.base64_encode( utl_raw.cast_to_raw(p_string)));
  END;



  /*{%skip}********************************************************************
   *
   *
   *  A collection of functions to convert string values into boolean
   *  and vice versa.
   *
   *
   ***************************************************************************/

  -- convert a char to boolean
  FUNCTION to_bool(p_val IN VARCHAR2) RETURN BOOLEAN
  IS
  BEGIN
    IF LOWER(p_val) IN ('y', 'yes', 'true', 'on',  '1') THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END;

-- convert a number to boolean
  FUNCTION to_bool(p_val IN NUMBER) RETURN BOOLEAN
  IS
    l_val NUMBER := ROUND(p_val, 0);
  BEGIN
    IF l_val = 0 THEN
      RETURN FALSE;
    ELSIF l_val > 0 THEN
      RETURN TRUE;
    ELSE
      RAISE_APPLICATION_ERROR(-20070, 'Invalid argument. Negative boolean ['||TO_CHAR(l_val)||']', FALSE);
      -- maybe handle as FALSE ?!
      -- RETURN FALSE;
    END IF;
  END;


  -- convert a boolean to standard char (true or false)
  /*
    According to theory a 1 BYTE char is less expensive then NUMBER or VARCHAR
    hence we go for a Y and N. Besides this is probably the most widly
    used convention for a boolean flag in Oracle anyways.
  */
  FUNCTION bool_to_char(p_val IN BOOLEAN) RETURN CHAR
  IS
  BEGIN
    IF p_val THEN
      RETURN 'Y';
    ELSE
      RETURN 'N';
    END IF;
  END;


  /*{%skip}********************************************************************
   *
   *
   *  A collection of procedures provide radix functionality.
   *
   *
   ***************************************************************************/


  /*

    Takes a number between 0 and 15, and converts it to a string (character)
    The to_radix_string() function calls this function.

    The caller of this function is responsible for making sure no invalid
    number is passed as the argument.  Valid numbers include non-negative
    integer in the radix used by the calling function.  For example,
    to_octal_string() must pass nothing but 0, 1, 2, 3, 4, 5, 6, and 7 as the
    argument 'num' of digit_to_string().

    %param   p_num    The decimal number to convert to hex.

    %return The character representation of the number in hex (0-15).

  */
  FUNCTION digit_to_string(p_num IN NUMBER) RETURN VARCHAR2
  IS
  BEGIN
    IF (p_num < 10) THEN
      RETURN to_char(p_num);
    ELSE
      RETURN chr(ascii('A') + p_num - 10);
    END IF;
  END;


  /*

    Takes a character (varchar2(1)) and converts it to a number.
    The parse_number() function calls this function.

    The caller of this function is responsible for maksing sure no invalid
    string is passed as the argument.  The caller can do this by first
    calling the is_valid_radix_num_string() function.

    %param   p_digit_str  The character to convert to decimal.

    %return The decimal representation of the character.

  */
  FUNCTION digit_to_decimal(p_digit_str IN VARCHAR2) RETURN NUMBER
  IS
  BEGIN
    IF (p_digit_str >= '0') AND (p_digit_str <= '9') THEN
      RETURN ascii(p_digit_str) - ascii('0');
    ELSIF (p_digit_str >= 'A') AND (p_digit_str <= 'F') THEN
      RETURN ascii(p_digit_str) - ascii('A') + 10;
    END IF;
  END;


  /*

    Checks if the given string represents a valid number in given radix.

    %param    p_string  ...
    %param    p_radix   The radix to be converted to (eg. 8 for octal, 2 for binary or 16 for hex).

    %return   True if valid and p_string as radix. and p_string will be the upper case of the radix.

    %raises   ORA-6502 if p_string is invalid.

  */
  FUNCTION is_valid_radix_num_string( p_string  IN OUT VARCHAR2
                                     ,p_radix   IN NUMBER) RETURN BOOLEAN
  IS
    l_valid_chars VARCHAR2(16) := '0123456789ABCDEF';
    l_valid       NUMBER;
    l_len         NUMBER;
    i             NUMBER;
    l_result      BOOLEAN;
  BEGIN
    IF (p_radix < 2) OR (p_radix > 16) OR (p_radix != trunc(p_radix)) THEN
      i := to_number('invalid number');  /* Forces ORA-6502 when bad radix. */
    END IF;
    p_string := upper(p_string);  /* a-f ==> A-F */
    -- determine valid characters for given radix
    l_valid_chars := substr('0123456789ABCDEF', 1, p_radix);
    l_valid := 1;
    l_len := length(p_string);
    i := 1;

    WHILE (l_valid != 0) LOOP
      l_valid := instr(l_valid_chars, substr(p_string, i, 1));
      i := i + 1;
    END LOOP;

    IF (l_valid = 0) THEN
      l_result := FALSE;
      i := to_number('invalid number');  /* Forces ORA-6502. */
    ELSE
      l_result := TRUE;
    END IF;

    RETURN l_result;
  END;


  -- Convert a number to string in given radix.
  FUNCTION to_radix_string( p_num     IN NUMBER
                           ,p_radix   IN NUMBER) RETURN VARCHAR2
  IS
    l_dividend  NUMBER;
    l_remainder NUMBER(2);
    l_result    VARCHAR2(2000);
  BEGIN
    /* NULL NUMBER -> NULL hex string */
    IF(p_num IS NULL) THEN
      RETURN NULL;
    ELSIF (p_num=0) THEN  /* special case */
      RETURN '0';
    END IF;

    /* invalid number or radix; force ORA-6502: PL/SQL: numeric or value err */
    IF     (p_num<0)
        OR (p_num!=trunc(p_num))
        OR (p_radix<2)
        OR (p_radix>16)
        OR (p_radix!=trunc(p_radix))
    THEN
      l_result := to_char(to_number('invalid number'));  /* Forces ORA-6502. */
    ELSE
      l_dividend := p_num;
      l_result := '';  /* start with a null string */

      /* the actual conversion loop */
      WHILE(l_dividend != 0) LOOP
        l_remainder := mod(l_dividend, p_radix);
        l_result := digit_to_string(l_remainder) || l_result;
        l_dividend := trunc(l_dividend / p_radix);
      END LOOP;
    END IF;
    RETURN l_result;
  END;


  -- convert a number to binary string
  FUNCTION to_binary_string(p_num IN NUMBER) RETURN VARCHAR2
  IS
  BEGIN
    RETURN to_radix_string(p_num, 2);
  END;


  -- convert a number to hexadecimal string
  FUNCTION to_hex_string(p_num IN NUMBER) RETURN VARCHAR2
  IS
  BEGIN
    RETURN to_radix_string(p_num, 16);
  END;


  -- convert a number to octal string.
  FUNCTION to_octal_string(p_num IN NUMBER) RETURN VARCHAR2
  IS
  BEGIN
    RETURN to_radix_string(p_num, 8);
  END;



  -- converts a string in given radix to a number
  FUNCTION parse_number( p_string IN VARCHAR2
                        ,p_radix  IN NUMBER) RETURN NUMBER
  IS
    l_str  VARCHAR2(2000) := p_string;
    l_len  NUMBER;
    l_dec  NUMBER;
  BEGIN
    /* NULL hex string -> NULL NUMBER */
    IF(l_str IS NULL) THEN
      RETURN NULL;
    END IF;

    IF (is_valid_radix_num_string(l_str, p_radix) = FALSE) THEN
      RETURN -1;  /* Never executes because is_valid_radix_num_string forced ORA-6502. */
    END IF;

    l_len := length(l_str);
    l_dec := 0;

    /* the actual conversion loop */
    FOR i IN 1..l_len LOOP
      l_dec := l_dec * p_radix + digit_to_decimal(substr(l_str, i, 1));
    END LOOP;

    RETURN l_dec;
  END;


END util_string;
/

show errors
