/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Create string agg distinct type
pro

CREATE OR REPLACE TYPE util.t_aggstr_distinct AS OBJECT
(
/******************************************************************************

  Aggregate type to concatenate strings up to 4000 chars in total length that
  is comma delimited. The result of the group is distinct and it can be assumed
  that the result is a unique list.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/t_aggstr_distinct.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  23/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  total VARCHAR2(4000),
  is_first NUMBER,
  sep VARCHAR2(20),

  STATIC FUNCTION ODCIAggregateInitialize(sctx IN OUT t_aggstr_distinct) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(self IN OUT t_aggstr_distinct, value IN VARCHAR2) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(self IN t_aggstr_distinct, returnValue OUT VARCHAR2, flags IN NUMBER) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(self IN OUT t_aggstr_distinct, ctx2 IN t_aggstr_distinct) RETURN NUMBER

);
/

show errors


CREATE OR REPLACE TYPE BODY util.t_aggstr_distinct
IS

  STATIC FUNCTION ODCIAggregateInitialize(sctx IN OUT t_aggstr_distinct) RETURN NUMBER
  IS
  BEGIN
    sctx := t_aggstr_distinct( null, 1, ', ' );
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateIterate(self IN OUT t_aggstr_distinct, value IN VARCHAR2) RETURN NUMBER
  IS
  BEGIN
    IF self.is_first = 1 THEN
      self.is_first := 0;
      self.total := value;
    ELSE
      -- only add if not already in string
      IF INSTR(self.total, value, 1) = 0 THEN
        self.total := self.total || self.sep || value;
      END IF;
    END IF;
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateTerminate(self IN t_aggstr_distinct, returnValue OUT VARCHAR2, flags IN NUMBER) RETURN NUMBER
  IS
  BEGIN
    returnValue := self.total;
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateMerge(self IN OUT t_aggstr_distinct, ctx2 IN t_aggstr_distinct) RETURN NUMBER
  IS
  BEGIN
    -- TODO: need to loop 2nd context and only add to first if not already in the 1st context
    -- if run in parallel then we want to concat the parallel concat to the first one ...
    IF NVL(length(ctx2.total), 0) > 0 THEN
      self.total := self.total || self.sep;
    END IF;
    self.total := self.total || ctx2.total;
    RETURN ODCIConst.Success;
  END;
END;
/

show errors

