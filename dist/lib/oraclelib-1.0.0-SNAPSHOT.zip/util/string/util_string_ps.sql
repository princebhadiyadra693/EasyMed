/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_string
pro
CREATE OR REPLACE PACKAGE util.util_string AS
/******************************************************************************

  Utility package to manage string related functionality.

  This package provides string functions such as generating hex strings from
  numbers.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/util_string_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  29/01/2004  Bertram        Initial Version                         <br>
   1.1  23/10/2008  Bertram        Made sprintf first arg optional.        <br>

******************************************************************************/

  /*{%skip}********************************************************************
   *
   *
   *  A collection of procedures to manage string replace functionality.
   *
   *
   ***************************************************************************/

  /**

    Replaces each occurence of %s with the provided arguments in order.
    This function can replace up to 15 arguments in the string.

    %Note: Similar to sprintf in C.

    %Usage: SELECT util_string.sprintf('This is %s a %s.', 'not', 'joke')
            FROM dual;
            results into 'This is not a joke'

    %param p_string       The string containing the delimiters to be replaced.
    %param p_arg1         The 1st argument to replace the 1st occurence of %s.
    %param p_arg2         The 2nd argument to replace the 2nd occurence of %s.
    %param p_arg3         The 3rd argument to replace the 3rd occurence of %s.
    %param p_arg4         The 4th argument to replace the 4th occurence of %s.
    %param p_arg5         The 5th argument to replace the 5th occurence of %s.
    %param p_arg6         The 6th argument to replace the 6th occurence of %s.
    %param p_arg7         The 7th argument to replace the 7th occurence of %s.
    %param p_arg8         The 8th argument to replace the 8th occurence of %s.
    %param p_arg9         The 9th argument to replace the 9th occurence of %s.
    %param p_arg10        The 10th argument to replace the 10th occurence of %s.
    %param p_arg11        The 11th argument to replace the 11th occurence of %s.
    %param p_arg12        The 12th argument to replace the 12th occurence of %s.
    %param p_arg13        The 13th argument to replace the 13th occurence of %s.
    %param p_arg14        The 14th argument to replace the 14th occurence of %s.
    %param p_arg15        The 15th argument to replace the 15th occurence of %s.

    %return               The string with the %s replaced by the nth argument.

  */
  FUNCTION sprintf( p_string IN VARCHAR2
                   ,p_arg1   IN VARCHAR2 DEFAULT NULL
                   ,p_arg2   IN VARCHAR2 DEFAULT NULL
                   ,p_arg3   IN VARCHAR2 DEFAULT NULL
                   ,p_arg4   IN VARCHAR2 DEFAULT NULL
                   ,p_arg5   IN VARCHAR2 DEFAULT NULL
                   ,p_arg6   IN VARCHAR2 DEFAULT NULL
                   ,p_arg7   IN VARCHAR2 DEFAULT NULL
                   ,p_arg8   IN VARCHAR2 DEFAULT NULL
                   ,p_arg9   IN VARCHAR2 DEFAULT NULL
                   ,p_arg10  IN VARCHAR2 DEFAULT NULL
                   ,p_arg11  IN VARCHAR2 DEFAULT NULL
                   ,p_arg12  IN VARCHAR2 DEFAULT NULL
                   ,p_arg13  IN VARCHAR2 DEFAULT NULL
                   ,p_arg14  IN VARCHAR2 DEFAULT NULL
                   ,p_arg15  IN VARCHAR2 DEFAULT NULL) RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES (sprintf, WNDS, WNPS, RNDS, RNPS);


  /**

    Replaces only the first occurence of a string with the argument provided.

    %Note: If no occurence is found then the result will be the same as the
           provided string..

    %param p_string       The string containing the delimiters to be replaced.
    %param p_occur        The delimiters to be replaced by the following argument.
    %param p_arg          The argument to be used to replace the delimiter.

    %return               The new replaced string or the original string if the
                          occurence is not found.

  */
  FUNCTION replace_once( p_string  IN VARCHAR2
                        ,p_occur   IN VARCHAR2
                        ,p_arg     IN VARCHAR2) RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES (replace_once, WNDS, WNPS, RNDS, RNPS);


  /*{%skip}********************************************************************
   *
   *
   *  A collection of functions to convert string values into boolean
   *  and vice versa.
   *
   *
   ***************************************************************************/

  /*
    Convert a char to boolean.

    %param    p_val  The character value that is to be converted into a boolean TRUE or FALSE.

    %returns  TRUE if the value is somthing like Y, YES, TRUE OR like.
  */
  FUNCTION to_bool(p_val IN VARCHAR2) RETURN BOOLEAN;

  /*
    Convert a number to boolean.

    %param    p_val  The bumber value that is to be converted into a boolean TRUE or FALSE.

    %returns  TRUE if the value greater then 0, FALSE if the value is 0
              and exception if the value is less then 0.

    %raises   Exception if the value is less then 0.

  */
  FUNCTION to_bool(p_val IN NUMBER) RETURN BOOLEAN;


  /*
    Convert a boolean into a standard character flag Y or N.

    %param    p_val  The boolean value that is to be converted into Y or N

    %returns  Y if value is TRUE and N if value is FALSE.
  */
  FUNCTION bool_to_char(p_val IN BOOLEAN) RETURN CHAR;


  /*{%skip}********************************************************************
   *
   *
   *  A collection of procedures provide radix functionality.
   *
   *
   ***************************************************************************/

  /*
    Convert a number to binary string.

    %param    p_num   The number to convert into a binary representation.
    %returns  The binary reprentation of the number.
  */
  FUNCTION to_binary_string(p_num IN NUMBER) RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES (to_binary_string, WNDS, WNPS, RNDS, RNPS);

  /*
    Convert a number to hexadecimal string.

    %param    p_num   The number to convert into a hex representation.
    %returns  The hex reprentation of the number.
    */
  FUNCTION to_hex_string(p_num IN NUMBER) RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES (to_hex_string, WNDS, WNPS, RNDS, RNPS);

  /*
    Convert a number to octal string.

    %param    p_num   The number to convert into a octal representation.
    %returns  The octal reprentation of the number.
    */
  FUNCTION to_octal_string(p_num IN NUMBER) RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES (to_octal_string, WNDS, WNPS, RNDS, RNPS);


  /*
    Convert a number to string in given radix.
    Radix must be in the range [2, 16].

    %param    p_num   The number to convert into a radix representation.
    %param    p_radix The radix to be converted to (eg. 8 for octal, 2 for binary or 16 for hex).

    %returns  The radix reprentation of the number.
    %raises   ORA-6502: PL/SQL: numeric or value error if the number is invalid.

  */
  FUNCTION to_radix_string( p_num     IN NUMBER
                           ,p_radix   IN NUMBER) RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES (to_radix_string, WNDS, WNPS, RNDS, RNPS);


  /*

    Convert a string, expressed in given radix, to number.
    Radix must be in the range [2, 16].

    %param    p_string The string'ed number to convert into a number.
    %param    p_radix  The radix to be converted to (eg. 8 for octal, 2 for binary or 16 for hex).

    %returns  The number if the string was a valid number.

  */
  FUNCTION parse_number( p_string IN VARCHAR2
                        ,p_radix  IN NUMBER) RETURN NUMBER;
  PRAGMA RESTRICT_REFERENCES (parse_number, WNDS, RNDS);


  /*
    Base64 encodes a string.

    %param    p_string  The string to encode base 64.

    %returns  The base64 encoded string.

  */
  FUNCTION base64_encode( p_string IN VARCHAR2) RETURN VARCHAR2;

END util_string;
/

show error
