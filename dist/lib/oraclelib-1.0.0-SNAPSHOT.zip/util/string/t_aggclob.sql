/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Create clob agg type
pro

CREATE OR REPLACE TYPE util.t_aggclob AS OBJECT
(
/******************************************************************************

  Aggregate type to concatenate strings over 4000 characters in total as a
  comma delimited list. Please note the return type is a temporary CLOB and you
  will need to make sure it is transferred into a table lob when inserting it
  into a table.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/t_aggclob.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  23/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  total CLOB,
  is_first NUMBER,
  sep VARCHAR2(20),

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT t_aggclob) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(self IN OUT t_aggclob, val IN VARCHAR2) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(self IN OUT t_aggclob, returnValue OUT NOCOPY CLOB, flags IN NUMBER) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(self IN OUT t_aggclob, ctx2 IN OUT t_aggclob) RETURN NUMBER

);
/

show errors


CREATE OR REPLACE TYPE BODY util.t_aggclob
IS

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT t_aggclob) RETURN NUMBER
  IS
  BEGIN
    ctx := t_aggclob( null, 1, ', ');
    dbms_lob.createtemporary(ctx.total, TRUE, 1); -- 1 - session. 2 - call
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateIterate(self IN OUT t_aggclob, val IN VARCHAR2) RETURN NUMBER
  IS
    l_val_amt BINARY_INTEGER;
    l_sep_amt BINARY_INTEGER;
  BEGIN

    l_val_amt := NVL(LENGTH(val), 0);
    l_sep_amt := NVL(LENGTH(self.sep), 0);

    IF self.is_first = 1 THEN
      self.is_first := 0;
    ELSE
      -- append the separator
      dbms_lob.writeappend(self.total, l_sep_amt, self.sep);
    END IF;

    -- then append value
    dbms_lob.writeappend(self.total, l_val_amt, val);

    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateTerminate(self IN OUT t_aggclob, returnValue OUT NOCOPY CLOB, flags IN NUMBER) RETURN NUMBER
  IS
  BEGIN
    -- we can net get around doing a deep copy since one can not have more then 1 handle to a temp lob (see Oracle Docs)
    -- and we need to populate returnValue
    returnValue := self.total;
    dbms_lob.freetemporary(self.total);
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateMerge(self IN OUT t_aggclob, ctx2 IN OUT t_aggclob) RETURN NUMBER
  IS
    l_sep_amt BINARY_INTEGER;
  BEGIN
    -- if run in parallel then we want to concat the parallel concat to the first one ...
    IF dbms_lob.getlength(ctx2.total) > 0 THEN
      l_sep_amt := NVL(LENGTH(self.sep), 0);
      dbms_lob.writeappend(self.total, l_sep_amt, self.sep);
    END IF;
    dbms_lob.append(self.total, ctx2.total);
    dbms_lob.freetemporary(ctx2.total);
    RETURN ODCIConst.Success;
  END;

END;
/

show errors

