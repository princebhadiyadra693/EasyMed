/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Create clob expression agg type
pro

CREATE OR REPLACE TYPE util.t_aggclob_exp AS OBJECT
(
/******************************************************************************

  Aggregate type to concatenate strings over 4000 characters in total as a
  delimited list which is specified in the aggexp expression. Please note the
  return type is a temporary CLOB and you will need to make sure it is
  transferred into a table lob when inserting it into a table.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/t_aggclob_exp.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  23/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  total CLOB,
  is_first NUMBER,
  sep VARCHAR2(20),

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT t_aggclob_exp) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(self IN OUT t_aggclob_exp, val IN t_aggexp) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(self IN OUT t_aggclob_exp, returnValue OUT NOCOPY CLOB, flags IN NUMBER) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(self IN OUT t_aggclob_exp, ctx2 IN OUT t_aggclob_exp) RETURN NUMBER

);
/

show errors


CREATE OR REPLACE TYPE BODY util.t_aggclob_exp
IS

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT t_aggclob_exp) RETURN NUMBER
  IS
  BEGIN
    -- init
    ctx := t_aggclob_exp( null, 1, ', ');
    dbms_lob.createtemporary(ctx.total, TRUE, dbms_lob.CALL); -- 1 - session. 2 - call
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateIterate(self IN OUT t_aggclob_exp, val IN t_aggexp) RETURN NUMBER
  IS
    l_val_amt BINARY_INTEGER;
    l_sep_amt BINARY_INTEGER;
  BEGIN

    self.sep := val.sep;

    l_val_amt := NVL(LENGTH(val.str), 0);
    l_sep_amt := NVL(LENGTH(self.sep), 0);

    IF self.is_first = 1 THEN
      self.is_first := 0;
    ELSE
      -- append the separator
      dbms_lob.writeappend(self.total, l_sep_amt, self.sep);
    END IF;
    -- then append value
    dbms_lob.writeappend(self.total, l_val_amt, val.str);

    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateTerminate(self IN OUT t_aggclob_exp, returnValue OUT NOCOPY CLOB, flags IN NUMBER) RETURN NUMBER
  IS
  BEGIN
    -- we can net get around doing a deep copy since one can not have more then 1 handle to a temp lob (see Oracle Docs)
    -- and we need to populate returnValue
    returnValue := self.total;
    dbms_lob.freetemporary(self.total);
    RETURN ODCIConst.Success;
  END;

  MEMBER FUNCTION ODCIAggregateMerge(self IN OUT t_aggclob_exp, ctx2 IN OUT t_aggclob_exp) RETURN NUMBER
  IS
    l_sep_amt BINARY_INTEGER;
  BEGIN
    -- if run in parallel then we want to concat the parallel concat to the first one ...
    IF dbms_lob.getlength(ctx2.total) > 0 THEN
      l_sep_amt := NVL(LENGTH(self.sep), 0);
      dbms_lob.writeappend(self.total, l_sep_amt, self.sep);
    END IF;
    dbms_lob.append(self.total, ctx2.total);
    dbms_lob.freetemporary(ctx2.total);
    RETURN ODCIConst.Success;
  END;

END;
/

show errors

