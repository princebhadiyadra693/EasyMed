/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_lob
pro
CREATE OR REPLACE PACKAGE util.util_lob AS
/******************************************************************************

  A utility package for the nice and nifty lob features.

  This package provides some useful tools to make dealing with clobs a bit
  easier.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/util_lob_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  25/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  -- the return type of the clob to rows
  TYPE a_clob_row IS TABLE OF VARCHAR2(32767);

  -- the maximum line length we can return as a string in SQL
  MAX_LINE_LENGTH CONSTANT NUMBER := 32767;

  -- the default line terminator is a CR but can be set to anything else
  DEFAULT_LINE_TERMINATOR CONSTANT VARCHAR2(1 BYTE) := CHR(10);

  /*

    Function to separate a clob into lines either terminated by CR or specified.

    %Usage    To view a CLOB split into lines (max 32767 characters long):
              SQL> SELECT * FROM TABLE(util_lob.clob_to_rows(MY_CLOB));

    %param  p_clob        The clob to split into rows
    %param  p_line        The max length of a line (eg. where the utility will split the line)
    %param  p_terminator  Line terminator to append to the end of the row.

    %return Pipelined result that can be selected with the SQL TABLE() statement.

  */
  FUNCTION clob_to_rows( p_clob         IN CLOB
                        ,p_line         IN NUMBER   DEFAULT MAX_LINE_LENGTH
                        ,p_terminator   IN VARCHAR2 DEFAULT DEFAULT_LINE_TERMINATOR) RETURN util_lob.a_clob_row PIPELINED;
  PRAGMA RESTRICT_REFERENCES (clob_to_rows, RNDS, WNDS, WNPS);

END util_lob;
/

show errors

