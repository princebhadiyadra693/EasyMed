/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_lob
pro
CREATE OR REPLACE PACKAGE BODY util.util_lob AS
/******************************************************************************

  A utility package for the nice and nifty lob features.

  This package provides some useful tools to make dealing with clobs a bit
  easier.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/util_lob_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  25/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  -- split a clob into record rows
  FUNCTION clob_to_rows( p_clob         IN CLOB
                        ,p_line         IN NUMBER   DEFAULT MAX_LINE_LENGTH
                        ,p_terminator   IN VARCHAR2 DEFAULT DEFAULT_LINE_TERMINATOR) RETURN util_lob.a_clob_row PIPELINED
  AS
    l_amount  NUMBER;
    l_pos     NUMBER := 1;
    l_idx     INTEGER := 0;
    l_len     NUMBER;
  BEGIN
    IF p_line > util_lob.MAX_LINE_LENGTH THEN
      raise_application_error(-20000, 'Max line must not exceed 32767.');
    END IF;
    l_len := dbms_lob.getlength(p_clob);
    -- get the index of endl
    LOOP
      -- the absolute index of the next line terminator
      l_idx := dbms_lob.instr(p_clob, p_terminator, l_pos);
      IF l_idx > 0 AND (l_idx - l_pos) < p_line THEN
      -- if endl found and idx - pos < p_line then
        l_amount := l_idx - l_pos;
      -- else endl not found or line larger then p_line so chomp away p_line
      ELSE
        -- if remaining bit is larger then p_line do p_line
        -- else do remaining bit
        IF (l_len - l_pos) > p_line THEN
          l_amount := p_line;
        ELSE
          l_amount := (l_len + length(p_terminator)) - l_pos;
        END IF;
      END IF;

      -- need to skip 1 if read line to the endl
      IF l_amount = 0 THEN
        l_pos := l_pos + length(p_terminator);
      ELSE
        PIPE ROW( dbms_lob.substr(p_clob, l_amount, l_pos) );
        -- next line please
        l_pos := l_pos + l_amount;
      END IF;
    EXIT WHEN l_pos >= l_len;
    END LOOP;
  END clob_to_rows;

END util_lob;
/

show errors

