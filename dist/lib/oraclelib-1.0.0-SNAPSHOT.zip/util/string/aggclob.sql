/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Create clob agg function
pro
/******************************************************************************

  Aggregate function to concatenate strings over 4000 characters in total as a
  comma delimited list. Please note the return type is a temporary CLOB and you
  will need to make sure it is transferred into a table lob when inserting it
  into a table.


  %Usage:     SQL> SELECT aggclob(l.column) FROM big_bla l;

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/string/aggclob.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  23/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

CREATE OR REPLACE FUNCTION util.aggclob(input VARCHAR2) RETURN CLOB PARALLEL_ENABLE AGGREGATE USING t_aggclob;
/

show errors

