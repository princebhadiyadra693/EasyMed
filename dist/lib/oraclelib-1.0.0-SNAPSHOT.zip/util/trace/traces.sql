pro Creating table traces
pro
/******************************************************************************

  Table is used to create a trace history and associated trace files since we
  cannot directly list files in the UDUMP dir in Oracle (well at least not in
  the XE edition). And even if we could, we would have no clue which session this
  trace file came from.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/trace/traces.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  24/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

CREATE TABLE util.traces( sid           NUMBER            NOT NULL
                         ,serial#       NUMBER            NOT NULL
                         ,username      VARCHAR2(30 BYTE)
                         ,module        VARCHAR2(48 BYTE)
                         ,action        VARCHAR2(32 BYTE)
                         ,trc_file_name VARCHAR2(255)
                         ,trc_level     NUMBER(2)         NOT NULL
                         ,created_date  DATE              NOT NULL
                         ,created_by    VARCHAR2(30)      NOT NULL)
PCTFREE 1 PCTUSED 85
/


