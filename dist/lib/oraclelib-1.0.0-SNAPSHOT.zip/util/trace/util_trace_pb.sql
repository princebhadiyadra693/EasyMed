/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_trace
pro
CREATE OR REPLACE PACKAGE BODY util.util_trace AS
/******************************************************************************

  Simple trace framework to allow users to enable/disable tracing for own and
  other sessions.

  TODO: - check trace file for current session and other session
        - cleanup traces table

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/trace/util_trace_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  25/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/


  -- enable trace for current session
  PROCEDURE trc( p_level    IN NUMBER DEFAULT LVL_NORMAL)
  IS
  BEGIN
    trc(NULL, NULL, p_level);
  END;

  -- disable trace for current session
  PROCEDURE trc_off
  IS
  BEGIN
    trc(NULL, NULL, LVL_OFF);
  END;


  -- enable trace for current session
  PROCEDURE trc( p_sid      IN NUMBER
                ,p_serial   IN NUMBER
                ,p_level    IN NUMBER DEFAULT LVL_NORMAL)
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_sid           NUMBER := p_sid;
    l_serial        NUMBER := p_serial;
    l_user          VARCHAR2(30 BYTE);
    l_module        VARCHAR2(48 BYTE);
    l_action        VARCHAR2(32 BYTE);
    l_trc           VARCHAR2(255);
    l_bfile         BFILE;
  BEGIN

    -- must provide sid and serial or both null to trace own session
    IF (p_sid IS NULL AND p_serial IS NOT NULL) OR (p_sid IS NOT NULL AND p_serial IS NULL) THEN
      raise_application_error(-20000, 'Either trace another session or your own.');
    END IF;

    -- validate level provided
    IF p_level NOT IN(LVL_OFF, LVL_NORMAL, LVL_BINDS, LVL_WAITS, LVL_BINDS_AND_WAITS) THEN
      -- TODO: raise proper exception
      raise_application_error(-20000, 'Valid trace levels are 0,1,4,8,12');
    END IF;

    -- get current session identifyer
    IF p_sid IS NULL AND p_serial IS NULL THEN
      BEGIN
        -- is self being traced, but don't care if not targettable user
        -- need to execute immediate due to v$mystat not grantable to role ...
        EXECUTE IMMEDIATE 'SELECT s.sid, s.serial# '||
                          'FROM   v$session s, v$mystat t ' ||
                          'WHERE  s.audsid = userenv(''sessionid'') '||
                          'AND    s.sid = t.sid '||
                          'AND ROWNUM = 1' INTO l_sid, l_serial;

      EXCEPTION
      WHEN no_data_found THEN
        raise_application_error(-20000,   'Session not found.');
      END;
    END IF;

    -- enable trace or else disable trace
    IF p_level > 0 THEN
      -- TODO: logging
      dbms_output.put_line( sprintf('trace sid[%s] serial[%s] trc[%s]', l_sid, l_serial, l_trc) );

    -- TODO: merge on SID, SERIAL and TRACE File name !!

    -- update trace history merge on sid, serial and trc file
    INSERT INTO traces( created_date
                       ,created_by
                       ,sid
                       ,serial#
                       ,username
                       ,module
                       ,action
                       ,trc_file_name
                       ,trc_level)
      SELECT  SYSDATE
             ,USER
             ,s.sid
             ,s.serial#
             ,s.username
             ,s.module
             ,s.action
             ,lower(i.instance_name) || '_ora_' || ltrim(p.spid) || DECODE(pr.value, NULL, NULL ,'_'||pr.value) || '.trc' AS trc
             ,p_level
      FROM    v$session s
             ,v$process p
             ,v$instance i -- only to get the db instance name no joint needed
             ,v$parameter pr
      WHERE   s.sid = l_sid
      -- session processes
      AND     s.paddr = p.addr
      -- only want to have current user session
      -- TODO: AND     s.audsid = userenv('sessionid')
      -- tracefile identifyer can be set in orainit
      AND     pr.name = 'tracefile_identifier';

      -- switch session trace
      dbms_system.set_ev(l_sid,   l_serial,   10046,   p_level,   '');
      COMMIT;
    ELSE
      -- TODO: level is 0 so trace off
      NULL;
    END IF;
  END;


  -- disable tracing for a specified session
  PROCEDURE trc_off( p_sid      IN NUMBER
                    ,p_serial   IN NUMBER)
  IS
  BEGIN
    trc(p_sid, p_serial, LVL_OFF);
  END;


  -- display current sessions
  PROCEDURE display_sessions
  IS
    -- internal formatting procedure for command line output
    PROCEDURE output_line( p_arg1 IN VARCHAR2
                          ,p_arg2 IN VARCHAR2
                          ,p_arg3 IN VARCHAR2
                          ,p_arg4 IN VARCHAR2
                          ,p_arg5 IN VARCHAR2
                          ,p_arg6 IN VARCHAR2)
    IS
    BEGIN
      dbms_output.put_line(rpad(p_arg1,12)||rpad(p_arg2,12)||rpad(p_arg3,12)||rpad(p_arg4,12)||rpad(p_arg5,24)||rpad(p_arg6,30));
    END output_line;
  BEGIN
    dbms_output.enable(500000);

    -- write header
    output_line(chr(9), NULL, NULL, NULL, NULL, NULL);
    output_line( 'Session'
                ,'User'
                ,'OsUser'
                ,'Machine'
                ,'Module'
                ,'Status');
    output_line( '-----------'
                ,'-----------'
                ,'-----------'
                ,'-----------'
                ,'-----------------------'
                ,'---------------------');

    -- write all session records
    FOR sess IN ( SELECT  s.sid
                         ,serial#
                         ,username
                         ,CASE WHEN instr(s.osuser,'\') = 0 THEN
                            s.osuser
                          ELSE
                            SUBSTR(s.osuser, instr(s.osuser, '\')+1)
                          END AS osuser
                         ,CASE WHEN instr(s.machine,'\') = 0 THEN
                            lower(s.machine)
                          ELSE
                            lower(SUBSTR(s.machine, instr(s.machine, '\')+1))
                          END AS machine
                         ,nvl(substr(module,1,22),' ') module
                         ,decode(status,'ACTIVE','Currently running SQL',
                                        'INACTIVE','Idle for '||last_call_et||' secs',
                                        'KILLED','Dead session - do not use',
                                        'SNIPED','Timed out session - do not use',
                                        'Status = '||status) status
                  FROM v$session s
                  WHERE s.username IS NOT NULL
                  AND   s.username NOT IN ('ANONYMOUS'))
    LOOP
      output_line( sess.sid||'-'||sess.serial#
                  ,sess.username
                  ,sess.osuser
                  ,sess.machine
                  ,sess.module
                  ,sess.status);
     END LOOP;
  END;


  -- display available trace files
  PROCEDURE display_trc
  IS
    -- internal formatting procedure for command line output
    PROCEDURE output_line( p_arg1 IN VARCHAR2
                          ,p_arg2 IN VARCHAR2
                          ,p_arg3 IN VARCHAR2
                          ,p_arg4 IN VARCHAR2)
    IS
    BEGIN
      dbms_output.put_line(rpad(p_arg1,12)||rpad(p_arg2,12)||rpad(p_arg3,24)||rpad(p_arg4,30));
    END output_line;
  BEGIN
    dbms_output.enable(500000);

    -- write header
    output_line(chr(9), NULL, NULL, NULL);
    output_line( 'Session'
                ,'User'
                ,'Module'
                ,'Trace File');
    output_line( '-----------'
                ,'-----------'
                ,'----------------------'
                ,'------------------------------');

    -- write all session records
    FOR trc IN ( SELECT  sid
                        ,serial#
                        ,username
                        ,nvl(substr(module,1,22),' ') module
                        ,trc_file_name
                  FROM   traces t
                  ORDER BY t.created_date DESC)
    LOOP
      output_line( trc.sid||'-'||trc.serial#
                  ,trc.username
                  ,trc.module
                  ,trc.trc_file_name);
     END LOOP;
  END;


  -- rets content of a trace file (by name) as a temp clob
  FUNCTION get_trc(p_filename IN VARCHAR2) RETURN CLOB
  IS
    l_clob CLOB;
    l_trc_file BFILE;

    -- only used for reading bfile into clob
    l_off_1 INTEGER := 1;
    l_off_2 INTEGER := 1;
    l_lang INTEGER;
    l_warn INTEGER;
    l_csid NUMBER;
  BEGIN

    -- TODO: perhaps truncate the table or remove old files ? EXECUTE IMMEDIATE 'TRUNCATE TABLE util.traces';
    -- get trc file handle
    l_trc_file := bfilename('UDUMP_DIR', p_filename);
    IF dbms_lob.fileexists( l_trc_file ) = 0 THEN
      raise_application_error(-20000, 'Trace File ' || p_filename || ' does not exist.');
    END IF;
    dbms_lob.open(l_trc_file, dbms_lob.LOB_READONLY);

    -- create temp lob for the call
    dbms_lob.createtemporary(l_clob, TRUE, dbms_lob.CALL);

    -- read the file content into a clob
    l_lang := dbms_lob.DEFAULT_LANG_CTX;
    l_csid := dbms_lob.DEFAULT_CSID; -- in other regions we migth want to do NLS_CHARSET_ID('US7ASCII')

    dbms_lob.loadclobfromfile( l_clob
                              ,l_trc_file
                              ,dbms_lob.LOBMAXSIZE
                              ,l_off_1
                              ,l_off_2
                              ,l_csid
                              ,l_lang
                              ,l_warn);

    -- clean up the open file
    dbms_lob.fileclose(l_trc_file);

    RETURN l_clob;
  END;

END util_trace;
/

show errors