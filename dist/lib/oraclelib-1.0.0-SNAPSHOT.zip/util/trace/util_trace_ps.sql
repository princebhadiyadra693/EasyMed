/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_trace
pro
CREATE OR REPLACE PACKAGE util.util_trace AS
/******************************************************************************

  Simple trace framework to allow users to enable/disable tracing for own and
  other sessions.

  This package is used to wrap priviliged system calls and make them available
  to average users without exposing all the capabilities of dbms_system.
  The framework will keep track of the sessions that have been traced in table
  traces and by running the gettrace.sql script presents the selection of
  traces.

  %Note     The trace records are only recorded if the trace session was
            initiated by the util_trace package.

  %Usage    View traceable sessions:
            SQL> EXEC util_trace.display_sessions;

            Trace the current session:
            SQL> EXEC util_trace.trc;

            Trace some other session:
            SQL> EXEC util_trace.trc(sid, serial, level);

            View available traces:
            SQL> SELECT * FROM util.traces
            or
            SQL> EXEC util_trace.display_trc

            Retrieve trace files:
            SQL> @gettrace.sql

  Alternative Ways to enable tracing for a session.

  1. Using Oracle's debug tool

  UT1> connect internal as sysdba;

  --attach oradebug to the desired process
  UT1> oradebug setospid <spid>

  --   turn trace on with the desired level
  UT1> oradebug event 10046 trace name context forever, level 12

  --   turn trace off when enough data gathered
  UT1> oradebug event 10046 trace name context off

  The sid is the oracle database session id.

  The spid however is the oracle database thread id of a client session (server thread)
  eg. on windows oracle.exe thread number of the shadow process.


  2. in your own session

  SQL> alter session set events '10046 trace name context forever, level 12';


  3. Using dbms_system

  SQL> exec dbms_system.set_sql_trace_in_session(...);

  The package DBMS_SYSTEM is installed by running the script $ORACLE_HOME/rdbms/admin/dbmsutil.sql

  This script is normally called by $ORACLE_HOME/rdbms/admin/catproc.sql

  4. Using dbms_support

  SQL> exec dbms_support.start_sql_trace_in_session(sid, serial, waits, binds);

  The package DBMS_SUPPORT is installed by running the script $ORACLE_HOME/rdbms/admin/dbmssupp.sql
  This package might have been superceeded by dbms_system.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/trace/util_trace_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  25/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/


  LVL_OFF             CONSTANT NUMBER(2) := 0;
  LVL_NORMAL          CONSTANT NUMBER(2) := 1;
  LVL_BINDS           CONSTANT NUMBER(2) := 4;
  LVL_WAITS           CONSTANT NUMBER(2) := 8;
  LVL_BINDS_AND_WAITS CONSTANT NUMBER(2) := 12;


  /*

    Enable or disable tracing in current session.

    %param    p_level       The trace level to set for the trace (0 - off, 1 - normal, 4 - binds, 8 - waits, 12 - binds and waits)
                            Default is NORMAL

  */
  PROCEDURE trc( p_level    IN NUMBER DEFAULT LVL_NORMAL);


  /*

    Disable tracing in current session.

  */
  PROCEDURE trc_off;


  /*

    Enable or disable tracing for a specified session.

    %param    p_sid         The session id to trace.
    %param    p_serial      The session serial to trace.
    %param    p_level       The trace level to set for the trace (0 - off, 1 - normal, 4 - binds, 8 - waits, 12 - binds and waits)
                            Default is NORMAL

  */
  PROCEDURE trc( p_sid      IN NUMBER
                ,p_serial   IN NUMBER
                ,p_level    IN NUMBER DEFAULT LVL_NORMAL);


  /*

    Disable tracing for a specified session.

    %param    p_sid         The session id to trace.
    %param    p_serial      The session serial to trace.

  */
  PROCEDURE trc_off( p_sid      IN NUMBER
                    ,p_serial   IN NUMBER);


  /*

    Return current session information to server out.

    %return    The current sessions within the database.

  */
  PROCEDURE display_sessions;


  /*

    Return the trace files recorded by the trace utility to server out.

    %return    The session traces that have been recorded with this trace utility.

  */
  PROCEDURE display_trc;


  /*

    Gets a trace file content as temporary clob for a particular filename.

  */
  FUNCTION get_trc(p_filename IN VARCHAR2) RETURN CLOB;

END util_trace;
/

show errors
