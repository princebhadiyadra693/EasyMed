/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_email
pro
CREATE OR REPLACE PACKAGE util.util_email
IS
/******************************************************************************

  Utility package to manage email related functionality as a wrapper around the<br>
  complicated utl_smtp package.


  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/email/util_email_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %usage    To configure the application following needs to be run:
  
  
  

  %usage     <b>Email Address Format</b><br>
             The format of an email address is one of these:
              {*} 1) someone@some-domain
              {*} 2) "Someone at some domain" <someone@some-domain>
              {*} 3) Someone at some domain <someone@some-domain>

  %usage     <b>Sending an email to mutiple Email Addresses</b><br>
             The sender or recipientcan be a list of email addresses separated by either a [,] (Comma) or a [;](Semicolon).

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  29/05/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  /* {%skip} **************************************************************************


    Global Setup


  ************************************************************************************/

  -- The signature that will appear in the email's MIME header.
  MAILER_ID   CONSTANT VARCHAR2(256) := 'Oracle Mail';

  /*

    A unique string that demarcates boundaries of parts in a multi-part email.
    The string should not appear inside the body of any part of the email.
    Customize this if needed or generate this randomly dynamically.

  */
  BOUNDARY        CONSTANT VARCHAR2(256) := '-----7D81B75CCC90D2974F7A1CBD';

  -- The first boundary demarcation for the multipart.
  FIRST_BOUNDARY  CONSTANT VARCHAR2(256) := '--' || BOUNDARY || sys.utl_tcp.CRLF;

-- The finalising boundary demarcation for the multipart.
  LAST_BOUNDARY   CONSTANT VARCHAR2(256) := '--' || BOUNDARY || '--' || sys.utl_tcp.CRLF;

  -- A MIME type that denotes multi-part email (MIME) messages.
  MULTIPART_MIME_TYPE CONSTANT VARCHAR2(256) := 'multipart/mixed; boundary="'|| BOUNDARY || '"';

  -- The maximum line width of a binary attachement.
  MAX_BASE64_LINE_WIDTH CONSTANT PLS_INTEGER   := 76 / 4 * 3;


  /*
  
  Constants used to store and retrieve configuration settings from util_conf.
  
  */
    CONF_EMAIL_SECTION     CONSTANT VARCHAR2(256) := 'util.email';
    CONF_EMAIL_ENABLED     CONSTANT VARCHAR2(256) := 'smtp.enabled';
    -- configuration items
    CONF_EMAIL_HOST        CONSTANT VARCHAR2(256) := 'smtp.host';
    CONF_EMAIL_DOMAIN      CONSTANT VARCHAR2(256) := 'smtp.domain';
    CONF_EMAIL_PORT        CONSTANT VARCHAR2(256) := 'smtp.port';
    CONF_EMAIL_SSL_ENABLED CONSTANT VARCHAR2(256) := 'smtp.ssl.enabled';
    CONF_EMAIL_SSL_USER    CONSTANT VARCHAR2(256) := 'smtp.ssl.username';
    CONF_EMAIL_SSL_PWD     CONSTANT VARCHAR2(256) := 'smtp.ssl.pwd';
  
  /* {%skip} **************************************************************************


    Simple Email Functionality

    A simple email API for sending email in plain text in a single call.

    TODO: implement an asynchronous mailer (dbms_job)

  ************************************************************************************/


  /*

    A simple email API for sending email in plain text in a single call.

    %param sender       The sender of the email.
    %param recipients   The recipient or list of recipients.
    %param subject      The subject of the email.
    %param message      A simple text message to be sent with the email.

    %scope Public

  */
  PROCEDURE mail( sender     IN VARCHAR2
                 ,recipients IN VARCHAR2
                 ,subject    IN VARCHAR2
                 ,message    IN VARCHAR2);



  /* {%skip} **************************************************************************


    Extended Email Functionality

    Extended email API to send email in HTML or plain text with no size limit.


  ************************************************************************************/


  /*

    Start an advanced email with custom body and attachements.

    First, begin the email by util_email.begin_mail. Then, call util_email.write_text
    repeatedly to send email in ASCII piece-by-piece. Or, call util_email.write_mb_text
    to send email in non-ASCII or multi-byte character set.
    End the email with util_email.end_mail.

  */
  FUNCTION begin_mail( sender     IN VARCHAR2
                      ,recipients IN VARCHAR2
                      ,subject    IN VARCHAR2
                      ,mime_type  IN VARCHAR2    DEFAULT 'text/plain'
                      ,priority   IN PLS_INTEGER DEFAULT NULL) RETURN utl_smtp.connection;


  /*

    End the email.

  */
  PROCEDURE end_mail(conn IN OUT NOCOPY utl_smtp.connection);




  /* {%skip} **************************************************************************


    Data Write Methods


  ************************************************************************************/


  /*

    Write email body in ASCII

  */
  PROCEDURE write_text( conn    IN OUT NOCOPY utl_smtp.connection
                       ,message IN VARCHAR2);

  /*

    Write email body in non-ASCII (including multi-byte). The email body will
    be sent in the database character set.

  */
  PROCEDURE write_mb_text( conn    IN OUT NOCOPY utl_smtp.connection
                          ,message IN VARCHAR2);

  /*

  Write email body in binary

  */
  PROCEDURE write_raw( conn    IN OUT NOCOPY utl_smtp.connection
                      ,message IN RAW);


  /*

    Write a clob to the email body.

  */
PROCEDURE write_clob( conn    IN OUT NOCOPY utl_smtp.connection
                     ,p_clob  IN OUT NOCOPY CLOB);


  /* {%skip} **************************************************************************


    Attachements

    APIs to send email with attachments. Attachments are sent by sending
    emails in "multipart/mixed" MIME format. Specify that MIME format when
    beginning an email with begin_mail().


  ************************************************************************************/

  /*

    Send a single text attachment.

  */
  PROCEDURE attach_text( conn         IN OUT NOCOPY utl_smtp.connection
                        ,data         IN VARCHAR2
                        ,mime_type    IN VARCHAR2 DEFAULT 'text/plain'
                        ,inline       IN BOOLEAN  DEFAULT TRUE
                        ,filename     IN VARCHAR2 DEFAULT NULL
                        ,last         IN BOOLEAN  DEFAULT FALSE);

  /*

    Send a binary attachment. The attachment will be encoded in Base-64 encoding format.

  */
  PROCEDURE attach_base64( conn         IN OUT NOCOPY utl_smtp.connection
                          ,data         IN RAW
                          ,mime_type    IN VARCHAR2 DEFAULT 'application/octet'
                          ,inline       IN BOOLEAN  DEFAULT TRUE
                          ,filename     IN VARCHAR2 DEFAULT NULL
                          ,last         IN BOOLEAN  DEFAULT FALSE);



  /*

    Send an attachment with no size limit. First, begin the attachment
    with begin_attachment(). Then, call write_text repeatedly to send
    the attachment piece-by-piece. If the attachment is text-based but
    in non-ASCII or multi-byte character set, use write_mb_text() instead.
    To send binary attachment, the binary content should first be encoded in Base-64 encoding format
    using the native one in 9i. End the attachment with end_attachment.

  */
  PROCEDURE begin_attachment( conn         IN OUT NOCOPY utl_smtp.connection
                             ,mime_type    IN VARCHAR2 DEFAULT 'text/plain'
                             ,inline       IN BOOLEAN  DEFAULT TRUE
                             ,filename     IN VARCHAR2 DEFAULT NULL
                             ,transfer_enc IN VARCHAR2 DEFAULT NULL);

  /*

    End the attachment.

  */
  PROCEDURE end_attachment( conn IN OUT NOCOPY utl_smtp.connection
                           ,last IN BOOLEAN DEFAULT FALSE);







  /* {%skip}
   *
   *
   *
   * Email Session
   *
   *
   *
   */


  /*
    Extended email API to send multiple emails in a session for better
    performance. First, begin an email session with begin_session.
    Then, begin each email with a session by calling begin_mail_in_session
    instead of begin_mail. End the email with end_mail_in_session instead
    of end_mail. End the email session by end_session.
  */
  FUNCTION begin_session RETURN utl_smtp.connection;

  /*

    Begin an email in a session.

  */
  PROCEDURE begin_mail_in_session( conn       IN OUT NOCOPY utl_smtp.connection
                                  ,sender     IN VARCHAR2
                                  ,recipients IN VARCHAR2
                                  ,subject    IN VARCHAR2
                                  ,mime_type  IN VARCHAR2  DEFAULT 'text/plain'
                                  ,priority   IN PLS_INTEGER DEFAULT NULL);


  /*

    End an email session.

  */
  PROCEDURE end_session(conn IN OUT NOCOPY utl_smtp.connection);


  /*

    End an email in a session.

  */
  PROCEDURE end_mail_in_session(conn IN OUT NOCOPY utl_smtp.connection);

END;
/

show error

