/******************************************************************************

  Create stylesheet table.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/core/stylesheet.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/
CREATE TABLE util.stylesheet( name         VARCHAR2(200)
                             ,file_name    VARCHAR2(200)
                             ,description  VARCHAR2(2000)
                             ,xsl          SYS.XmlType NOT NULL
                             ,CONSTRAINT pk_stypesheet PRIMARY KEY (name) )
PCTFREE 1 PCTUSED 85
/

COMMENT ON TABLE  util.stylesheet             IS 'Table to store xslt stylesheets in native format.';
COMMENT ON COLUMN util.stylesheet.name        IS 'The internal name of the stylesheet ideally lower case and no spaces.';
COMMENT ON COLUMN util.stylesheet.file_name   IS 'The file name of the stylesheet loaded so we can backtrace where the source is coming from!';
COMMENT ON COLUMN util.stylesheet.description IS 'A sensible description of what this stylesheet will produce.';
COMMENT ON COLUMN util.stylesheet.xsl         IS 'The XSLT stylesheet stored.';
