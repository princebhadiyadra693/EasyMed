/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_locale
pro
CREATE OR REPLACE PACKAGE BODY util.util_locale AS
/******************************************************************************

  A utility package for internationalisation features.

  This package provides essentail locale features.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/core/util_locale_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  25/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  g_locale LOCALE;

  -- returns 'Y' if the locale is valid 'N' otherwise
  FUNCTION is_valid_locale(p_locale IN LOCALE) RETURN CHAR
  IS
  BEGIN
    IF p_locale IN (EN, DE, ES, IT)
    THEN
      RETURN 'Y';
    ELSE
      RETURN 'N';
    END IF;
  END;
  -- set the locale for the error messages
  PROCEDURE set_locale(p_locale IN LOCALE)
  IS
  BEGIN
    IF is_valid_locale(p_locale) = 'Y' THEN
      g_locale := p_locale;
    ELSE
      g_locale := EN;
      RAISE_APPLICATION_ERROR(-20000, 'Locale ['||p_locale||'] is not valid. Defaulted session locale to ['||EN||']', FALSE);
    END IF;
  END;

  -- return the locale for this session
  FUNCTION get_locale RETURN LOCALE
  IS
  BEGIN
    RETURN g_locale;
  END;

BEGIN
  -- you can add your initilisation here .. eg via CONTEXT or the like ...
  g_locale := EN;
END util_locale;
/

show error
