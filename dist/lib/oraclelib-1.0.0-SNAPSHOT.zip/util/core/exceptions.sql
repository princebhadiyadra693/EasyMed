/******************************************************************************

  Create an exception register to keep track of what exceptions have been
  defined and PRAGMA'ed.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/core/exceptions.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE TABLE util.exceptions( sqlcode       NUMBER(5,0)
                             ,locale        VARCHAR2(2 BYTE) -- make sure this is the same as util_locale.LOCALE
                             ,name          VARCHAR2(100)
                             ,default_text  VARCHAR2(300))
PCTFREE 1 PCTUSED 85
/

ALTER TABLE util.exceptions
  ADD CONSTRAINT pk_exceptions
  PRIMARY KEY ( sqlcode, locale )
/

ALTER TABLE util.exceptions
  ADD CONSTRAINT chk_exceptions_sqlcode
  CHECK ( sqlcode BETWEEN -20999 AND -20000 )
/

ALTER TABLE util.exceptions
  ADD CONSTRAINT uqe_exceptions_name
  UNIQUE ( name, locale )
/

CREATE OR REPLACE TRIGGER util.tbiu_exceptions
BEFORE INSERT OR UPDATE ON util.exceptions
FOR EACH ROW
/**

  Before insert or update ensure the exception name is stored in lower case.

*/
BEGIN
  :new.name := LOWER(:new.name);
  IF util_locale.is_valid_locale(:new.locale) = 'N' THEN
    RAISE_APPLICATION_ERROR(-20000, 'Locale '||:new.locale||' is not a valid locale.', FALSE);
  END IF;
END;
/

show error

COMMENT ON TABLE util.exceptions IS 'Exception register to track custom exception initialisation. Please note that this table is managed by util_exception and should not be populated manually.';
COMMENT ON COLUMN util.exceptions.sqlcode IS 'The Oracle SQLCODE used by RAISE_APPLICATION ERROR. Ideally this number is unique across all database apps hence part of the PK.';
COMMENT ON COLUMN util.exceptions.name IS 'The name of the exception as hardcoded in the INIT PRAGMA.';
COMMENT ON COLUMN util.exceptions.locale IS 'The locale of the error message. Default is util_locale.EN as managed by util_exception. Multiple locales can be configured for a particular error and the locale can be set for each session via util_local.set_locale(util_locale.LOCALE).';
COMMENT ON COLUMN util.exceptions.default_text IS 'The default text of the exception to raise. This text is part of the Oracle SQLERRM and can be extracted in the PL/SQL exception block, Java catch or the like.';
