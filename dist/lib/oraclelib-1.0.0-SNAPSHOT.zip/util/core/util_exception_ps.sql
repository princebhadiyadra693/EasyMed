/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_exception
pro
CREATE OR REPLACE PACKAGE util.util_exception AS
/******************************************************************************

  A utility package with essentail exception management features.

  This package provides essentail exception management features that allow the
  developers to extend and manage error numbers and exception messages.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/core/util_exception_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  25/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  --
  --
  -- IF YOU ADD AN EXCEPTION, PLEASE MAKE SURE YOU REGISTER IT TOO !!!
  -- refer to register() below for details
  --
  --

  -- standard exception
  generic EXCEPTION;
  PRAGMA EXCEPTION_INIT(generic, -20000);

  /*{%skip}**********************************************************************
   *
   *
   *  System exceptions.
   *
   *
   ******************************************************************************/

  -- Exception to be raised when a context or system wide value is not initialised.
  uninitialised EXCEPTION;
  PRAGMA EXCEPTION_INIT(uninitialised, -20010);

  already_initialised EXCEPTION;
  PRAGMA EXCEPTION_INIT(already_initialised, -20010);

  -- Exception to be raised when a user has no access to a particular application.
  no_user_access EXCEPTION;
  PRAGMA EXCEPTION_INIT(no_user_access, -20012);

  -- Exception to be raised when a user has no employee record.
  no_user_account EXCEPTION;
  PRAGMA EXCEPTION_INIT(no_user_account, -20013);

  -- Exception to be raised when a user logon fails.
  logon_failure EXCEPTION;
  PRAGMA EXCEPTION_INIT(logon_failure, -20014);


  /*{%skip}**********************************************************************
   *
   *
   *  Application exceptions.
   *
   *
   ******************************************************************************/

  -- Exception to be raised when the application specified is not valid.
  invalid_log_level EXCEPTION;
  PRAGMA EXCEPTION_INIT(invalid_log_level, -20050);


  /*{%skip}**********************************************************************
   *
   *
   *  File and text exceptions.
   *
   *
   ******************************************************************************/

  -- Exception to be raised when the application specified is not valid.
  file_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(file_exists, -20060);

  file_not_found EXCEPTION;
  PRAGMA EXCEPTION_INIT(file_not_found, -20061);

  -- used in conjunction with util_propery
  property_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(property_exists, -20065);

  property_not_found EXCEPTION;
  PRAGMA EXCEPTION_INIT(property_not_found, -20066);


  /*{%skip}**********************************************************************
   *
   *
   *  Interop exceptions.
   *
   *
   ******************************************************************************/

  -- Exception to be raised when the provided argument is not valid.
  invalid_argument EXCEPTION;
  PRAGMA EXCEPTION_INIT(invalid_argument, -20070);


  /*{%skip}**********************************************************************
   *
   *
   *  Procedures raise exceptions.
   *
   *
   ******************************************************************************/

  /**

    Raise a custom defined application error.

    %Note: A PRAGMA INIT_EXCEPTION does not need to be done in a package but is desirable
           if one would like to handle the exception programatically.

    %param p_name         The name of the exception to raise.
    %param p_arg1         The 1st argument to replace the 1st occurence of %s.
    %param p_arg2         The 2nd argument to replace the 2nd occurence of %s.
    %param p_arg3         The 3rd argument to replace the 3rd occurence of %s.
    %param p_arg4         The 4th argument to replace the 4th occurence of %s.
    %param p_arg5         The 5th argument to replace the 5th occurence of %s.
    %param p_arg6         The 6th argument to replace the 6th occurence of %s.
    %param p_arg7         The 7th argument to replace the 7th occurence of %s.
    %param p_arg8         The 8th argument to replace the 8th occurence of %s.
    %param p_arg9         The 9th argument to replace the 9th occurence of %s.
    %param p_keep_errors  If set to true it will keep all previous errors as well.
                          False will make this error the only on the error stack.


    %raises exception      Raises a default exception when the exception name
                           is not registered in the util.exceptions table.

  */
  PROCEDURE raise_stack( p_name         IN exceptions.name%TYPE
                        ,p_arg1         IN VARCHAR2 DEFAULT NULL
                        ,p_arg2         IN VARCHAR2 DEFAULT NULL
                        ,p_arg3         IN VARCHAR2 DEFAULT NULL
                        ,p_arg4         IN VARCHAR2 DEFAULT NULL
                        ,p_arg5         IN VARCHAR2 DEFAULT NULL
                        ,p_arg6         IN VARCHAR2 DEFAULT NULL
                        ,p_arg7         IN VARCHAR2 DEFAULT NULL
                        ,p_arg8         IN VARCHAR2 DEFAULT NULL
                        ,p_arg9         IN VARCHAR2 DEFAULT NULL
                        ,p_keep_errors  IN BOOLEAN  DEFAULT TRUE);
  PRAGMA RESTRICT_REFERENCES (raise_stack, WNDS, WNPS);

  /**

    Raise a custom defined application error without any previous errors.

    %Note: A PRAGMA INIT_EXCEPTION does not need to be done in a package but is desirable
           if one would like to handle the exception programatically.

    %param p_name         The name of the exception to raise.
    %param p_arg1         The 1st argument to replace the 1st occurence of %s.
    %param p_arg2         The 2nd argument to replace the 2nd occurence of %s.
    %param p_arg3         The 3rd argument to replace the 3rd occurence of %s.
    %param p_arg4         The 4th argument to replace the 4th occurence of %s.
    %param p_arg5         The 5th argument to replace the 5th occurence of %s.
    %param p_arg6         The 6th argument to replace the 6th occurence of %s.
    %param p_arg7         The 7th argument to replace the 7th occurence of %s.
    %param p_arg8         The 8th argument to replace the 8th occurence of %s.
    %param p_arg9         The 9th argument to replace the 9th occurence of %s.

    %raises exception      Raises a default exception when the exception name
                           is not registered in the util.exceptions table.

  */
  PROCEDURE raise( p_name         IN exceptions.name%TYPE
                  ,p_arg1         IN VARCHAR2 DEFAULT NULL
                  ,p_arg2         IN VARCHAR2 DEFAULT NULL
                  ,p_arg3         IN VARCHAR2 DEFAULT NULL
                  ,p_arg4         IN VARCHAR2 DEFAULT NULL
                  ,p_arg5         IN VARCHAR2 DEFAULT NULL
                  ,p_arg6         IN VARCHAR2 DEFAULT NULL
                  ,p_arg7         IN VARCHAR2 DEFAULT NULL
                  ,p_arg8         IN VARCHAR2 DEFAULT NULL
                  ,p_arg9         IN VARCHAR2 DEFAULT NULL);
  PRAGMA RESTRICT_REFERENCES (raise, WNDS, WNPS);

  /*

    Initialises the custom exceptions within its internal exception store.
    This procedure should be called after exceptions have been added to the
    package specification.

  */
  PROCEDURE register;
  PRAGMA RESTRICT_REFERENCES (register, WNPS);

END util_exception;
/

show errors
