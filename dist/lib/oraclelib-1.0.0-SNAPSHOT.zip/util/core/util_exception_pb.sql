/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_exception
pro
CREATE OR REPLACE PACKAGE BODY util.util_exception AS
/******************************************************************************

  A utility package with essentail exception management features.

  This package provides essentail exception management features that allow the
  developers to extend and manage error numbers and exception messages.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/core/util_exception_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  25/01/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  /*{%skip}**********************************************************************
   *
   *
   *  A collection of procedures exceptions.
   *
   *
   ******************************************************************************/

  -- raise custom exception
  PROCEDURE raise_stack( p_name         IN exceptions.name%TYPE
                        ,p_arg1         IN VARCHAR2 DEFAULT NULL
                        ,p_arg2         IN VARCHAR2 DEFAULT NULL
                        ,p_arg3         IN VARCHAR2 DEFAULT NULL
                        ,p_arg4         IN VARCHAR2 DEFAULT NULL
                        ,p_arg5         IN VARCHAR2 DEFAULT NULL
                        ,p_arg6         IN VARCHAR2 DEFAULT NULL
                        ,p_arg7         IN VARCHAR2 DEFAULT NULL
                        ,p_arg8         IN VARCHAR2 DEFAULT NULL
                        ,p_arg9         IN VARCHAR2 DEFAULT NULL
                        ,p_keep_errors  IN BOOLEAN  DEFAULT TRUE)
  IS
    l_code exceptions.sqlcode%TYPE;
    l_error exceptions.default_text%TYPE;
  BEGIN
    -- try to retrieve the locale specified and if not then just plain english oen
    SELECT  ex.sqlcode
           ,util_string.sprintf(ex.default_text, p_arg1, p_arg2, p_arg3 , p_arg4, p_arg5, p_arg6, p_arg7, p_arg8, p_arg9)
    INTO    l_code
           ,l_error
    FROM ( SELECT  e.sqlcode
                  ,e.default_text
                  ,e.locale
                  ,e.name
           FROM    exceptions e
           WHERE   e.name = p_name
           AND     e.locale IN ( SELECT NVL(ue.locale, util_locale.EN)
                                 FROM   exceptions ue
                                       ,( SELECT util_locale.get_locale AS locale FROM dual ) d
                                 WHERE d.locale = ue.locale(+)
                                 AND ue.name(+) = p_name
                                 AND   ue.locale(+) = util_locale.get_locale  -- TODO: remove
                                 )
           OR 'ES' IS NULL ) ex
    WHERE ROWNUM < 2;

    -- raise application error with specified code and text
    RAISE_APPLICATION_ERROR(l_code, l_error, p_keep_errors);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- development error !!!
      RAISE_APPLICATION_ERROR(-20000, 'Development Error: Exception '||p_name||' is not defined. Please review your setup.', FALSE);
  END;


  PROCEDURE raise( p_name         IN exceptions.name%TYPE
                  ,p_arg1         IN VARCHAR2 DEFAULT NULL
                  ,p_arg2         IN VARCHAR2 DEFAULT NULL
                  ,p_arg3         IN VARCHAR2 DEFAULT NULL
                  ,p_arg4         IN VARCHAR2 DEFAULT NULL
                  ,p_arg5         IN VARCHAR2 DEFAULT NULL
                  ,p_arg6         IN VARCHAR2 DEFAULT NULL
                  ,p_arg7         IN VARCHAR2 DEFAULT NULL
                  ,p_arg8         IN VARCHAR2 DEFAULT NULL
                  ,p_arg9         IN VARCHAR2 DEFAULT NULL)
  IS
  BEGIN
    raise_stack(p_name
               ,p_arg1
               ,p_arg2
               ,p_arg3
               ,p_arg4
               ,p_arg5
               ,p_arg6
               ,p_arg7
               ,p_arg8
               ,p_arg9
               ,p_keep_errors => FALSE);
  END;


  /*{%skip}**********************************************************************
   *
   *
   *  A collection of procedures to manage exception text.
   *
   *
   ******************************************************************************/


  /**

    Insert or update a custom defined exception.

    %Usage <pre>set_exception(-20060, 'file_not_found', 'File %s not found.');</pre>

    %param p_sqlcode      The sqlcode of the exception to set.
    %param p_name         The name of the exception to set.
    %param p_default_text The text to raise when this exception is thrown.

  */
  PROCEDURE set_exception( p_sqlcode      IN exceptions.sqlcode%TYPE
                          ,p_name         IN exceptions.name%TYPE
                          ,p_default_text IN exceptions.default_text%TYPE
                          ,p_locale       IN util_locale.LOCALE DEFAULT util_locale.EN)
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    IF util_locale.is_valid_locale(p_locale) = 'N' THEN
      RAISE_APPLICATION_ERROR(-20000, 'Development Error: Locale '||p_locale||' is not valid.', FALSE);
    END IF;

    -- merge exception message into the store
    MERGE INTO exceptions e
    USING ( SELECT  p_sqlcode       AS sqlcode
                   ,p_name          AS name
                   ,p_default_text  AS text
                   ,p_locale        AS locale
            FROM dual ) d
    ON (e.sqlcode = d.sqlcode AND e.name = d.name AND e.locale = d.locale)
    WHEN MATCHED THEN
      UPDATE SET e.default_text = d.text
    WHEN NOT MATCHED THEN
      INSERT (sqlcode, name, locale, default_text)
      VALUES (d.sqlcode, d.name, d.locale, d.text);
    COMMIT;
  END set_exception;

  /*

    Initialises the custom exceptions within its internal exception store.
    This procedure should be called after exceptions have been added to the
    package specification.

    Alternatively one can manage the exceptions as part of a static data
    registry. This procedure is only provided for convinience if not too
    many exceptions need to be managed.

  */
  PROCEDURE register
  IS
  BEGIN

    -- the generic exception (example multilingual support)
    set_exception(-20000, 'generic', 'Generic exception: %s.', util_locale.EN);
    set_exception(-20000, 'generic', 'Allgemeiner Fehler: %s.', util_locale.DE);
    set_exception(-20000, 'generic', 'Uno Problemo: %s.', util_locale.IT);

    -- system exceptions
    set_exception(-20010, 'uninitialised', '%s is not initialised.');
    set_exception(-20011, 'already_initialised', '%s is already initialised.');

    set_exception(-20012, 'no_user_access', '%s has no access to %s.');
    set_exception(-20013, 'no_user_account', '%s has no valid user account.');
    set_exception(-20014, 'logon_failure', 'Logon for %s failed.');

    -- framework exceptions
    set_exception(-20050, 'invalid_log_level', 'The specified level [%s] is invalid.');

    -- application exceptions
    set_exception(-20060, 'file_exists', 'File %s exists.');
    set_exception(-20061, 'file_not_found', 'File %s not found.');
    set_exception(-20065, 'property_exists', 'Property %s exists.');
    set_exception(-20066, 'property_not_found', 'Property %s does not exist.');

    -- interop exceptions
    set_exception(-20070, 'invalid_argument', '%s is not valid. %s');

  END;

END util_exception;
/

show errors
