/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_temporale
pro
CREATE OR REPLACE PACKAGE util.util_temporale AS
/******************************************************************************

  Utility package to manage date and timestamp related functionality.

  This package provides date and timestamp functions such as generating unix
  like times from timestamp or converting milliseconds back into a timestamp.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/datetime/util_temporale_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  08/12/2008  Bertram        Initial Version                         <br>

******************************************************************************/

  /*{%skip}********************************************************************
   *
   *
   *  A collection of procedures to manage unix timestamp functionality.
   *
   *
   ***************************************************************************/

  /**

    Returns the timestamp in milliseconds since 1/1/1970

    %Usage:

    %param p_timestamp    The timestamp to use.

    %return               The time in milliseconds since 1/1/1970

  */
  FUNCTION get_unix_timestamp(p_timestamp IN TIMESTAMP DEFAULT current_timestamp) RETURN NUMBER;
  PRAGMA RESTRICT_REFERENCES (get_unix_timestamp, WNDS, WNPS, RNPS);


END util_temporale;
/

show error
