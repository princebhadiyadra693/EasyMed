/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_temporale
pro
CREATE OR REPLACE PACKAGE BODY util.util_temporale AS
/******************************************************************************

  Utility package to manage date and timestamp related functionality.

  This package provides date and timestamp functions such as generating unix
  like times from timestamp or converting milliseconds back into a timestamp.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/datetime/util_temporale_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  08/12/2008  Bertram        Initial Version                         <br>

******************************************************************************/

  /*{%skip}********************************************************************
   *
   *
   *  A collection of procedures to manage unix timestamp functionality.
   *
   *
   ***************************************************************************/

  /**

    Returns the timestamp in milliseconds since 1/1/1970 GMT

    %Usage:

    %param p_timestamp    The timestamp to use.

    %return               The time in milliseconds since 1/1/1970

  */



  FUNCTION get_unix_timestamp(p_timestamp IN TIMESTAMP DEFAULT current_timestamp) RETURN NUMBER AS
    l_result NUMBER(38,0);
    l_utc_1970 TIMESTAMP;
    l_diff TIMESTAMP;
  BEGIN
    -- TODO move to package header as constant ...
    l_utc_1970 := TO_TIMESTAMP_TZ('01-JAN-1970 00:00:00 0:00', 'DD-MON-YYYY HH24:MI:SS TZH:TZM');
--    l_diff := p_timestamp - l_utc_1970;

    SELECT    ( ( TO_NUMBER( extract(DAY FROM dt) )    * 24 * 60 * 60 * 1000 ) +
                ( TO_NUMBER( extract(HOUR FROM dt) )        * 60 * 60 * 1000 ) +
                ( TO_NUMBER( extract(MINUTE FROM dt) )           * 60 * 1000 ) +
                ( TO_NUMBER( extract(SECOND FROM dt) )                * 1000 ) +
                ( TO_NUMBER(substr(TO_CHAR(p_timestamp,'FF'), 1,3)) )
              ) AS milliseconds
            INTO l_result
    --FROM ( SELECT p_timestamp - SYS_EXTRACT_UTC( TO_TIMESTAMP_TZ('01-JAN-1970','DD-MON-YYYY') ) dt FROM dual );
    FROM ( SELECT p_timestamp - l_utc_1970 dt FROM dual );
    RETURN l_result;
  END get_unix_timestamp;



END util_temporale;
/

show errors
