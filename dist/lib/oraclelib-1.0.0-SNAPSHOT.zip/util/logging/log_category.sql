PRO Create log_category table
PRO
/******************************************************************************

  Create logger configuration table.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/log_category.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE TABLE util.log_category(  name         VARCHAR2(100)
                                ,log_level    NUMBER(1,0)
                                ,CONSTRAINT pk_log_category PRIMARY KEY ( name ) )
/

ALTER TABLE util.log_category
ADD CONSTRAINT chk_log_level
CHECK ( log_level  BETWEEN 0 AND 9 )
/

COMMENT ON TABLE util.log_category IS 'Configuration table for loggers';
COMMENT ON COLUMN util.log_category.name IS 'The loggers category.';
COMMENT ON COLUMN util.log_category.log_level IS 'The category effective log threshold.';
