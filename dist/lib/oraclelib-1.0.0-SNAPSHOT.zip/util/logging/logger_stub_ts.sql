/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Type Spec logger stub
pro
CREATE OR REPLACE TYPE util.logger AS OBJECT
(
/******************************************************************************

  Common Logging Object (STUB).

  This Type is a stub of the real logging framework.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/logger_stub_ts.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %usage    To configure the application following needs to be run:

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  19/09/2008  Bertram        Initial Version                         <br>

******************************************************************************/

  /** the loggers effective category */
  provided_category VARCHAR2(100)
  /** the loggers effective category */
  ,effective_category VARCHAR2(100)
  /** the effective log level for the logger */
  ,log_level          NUMBER(1,0)

  ,MEMBER PROCEDURE severe(msg IN VARCHAR2)
  ,MEMBER PROCEDURE   warn(msg IN VARCHAR2)
  ,MEMBER PROCEDURE   info(msg IN VARCHAR2)
  ,MEMBER PROCEDURE  debug(msg IN VARCHAR2)
  ,MEMBER PROCEDURE  trace(msg IN VARCHAR2)

  ,MEMBER FUNCTION is_off    RETURN BOOLEAN
  ,MEMBER FUNCTION is_severe RETURN BOOLEAN
  ,MEMBER FUNCTION is_warn   RETURN BOOLEAN
  ,MEMBER FUNCTION is_info   RETURN BOOLEAN
  ,MEMBER FUNCTION is_debug  RETURN BOOLEAN
  ,MEMBER FUNCTION is_trace  RETURN BOOLEAN

  ,MEMBER FUNCTION get_category RETURN VARCHAR2
  ,MEMBER FUNCTION get_level RETURN PLS_INTEGER
  ,MEMBER PROCEDURE set_level(p_level IN NUMBER)

  ,STATIC FUNCTION get_logger(p_category IN VARCHAR2) RETURN Logger

);
/

show errors
