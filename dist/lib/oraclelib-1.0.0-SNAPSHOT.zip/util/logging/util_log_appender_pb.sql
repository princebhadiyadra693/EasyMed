/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_log_appender
pro
CREATE OR REPLACE PACKAGE BODY util.util_log_appender
IS
/******************************************************************************

  Console Log Appender.

  This Package implements a console log appender.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/util_log_appender_pb.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  28/10/2008  Bertram        Initial Version                         <br>

******************************************************************************/

  PROCEDURE add_appender( p_category      IN log_category.name%TYPE
                         ,p_name          IN log_appender.name%TYPE
                         ,p_appender_type IN log_appender.appender_type%TYPE
                         ,p_level         IN log_category.log_level%TYPE DEFAULT NULL)
  IS
   PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

    INSERT INTO log_appender( name
                             ,appender_type
                             ,category
                             ,property_name
                             ,property_value )
    SELECT  p_name AS appender_name
           ,a.name AS appender_type
           ,l.name AS category_name
           ,util_log_appender.LEVEL_PROPERTY AS log_name
           ,NVL(p_level, l.log_level) AS log_level
    FROM    log_category l
           ,log_appender_type a
    WHERE l.name = p_category
    AND   a.name = p_appender_type;

    -- TODO: check for no records inserted

    COMMIT;
  END;



  PROCEDURE add_appender_property( p_category       IN log_category.name%TYPE
                                  ,p_name           IN log_appender.name%TYPE
                                  ,p_property_name  IN log_appender.property_name%TYPE
                                  ,p_property_value IN log_appender.property_value%TYPE)
  IS
   PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- TODO validate input
    -- TODO merge so we can configure it later on
    INSERT INTO log_appender( name
                             ,appender_type
                             ,category
                             ,property_name
                             ,property_value )
    SELECT  a.name           AS appender_name
           ,a.appender_type  AS appender_type
           ,a.category       AS category_name
           ,p_property_name  AS prop_name
           ,p_property_value AS prop_val
    FROM    log_appender a
    WHERE a.name = p_name
    AND   a.category = p_category
    AND   a.property_name = util_log_appender.LEVEL_PROPERTY;

    -- TODO: check for no records inserted

    COMMIT;
  END;




  PROCEDURE register( p_name         IN log_appender_type.name%TYPE
                     ,p_impl_schema  IN log_appender_type.impl_schema%TYPE
                     ,p_impl_name    IN log_appender_type.impl_name%TYPE)
  IS
   PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    MERGE INTO log_appender_type l
    USING ( SELECT  p_name         AS n
                   ,p_impl_schema  AS s
                   ,p_impl_name    AS i
            FROM dual ) d
    ON ( l.name = d.n )
    WHEN MATCHED THEN
      UPDATE SET l.impl_name = d.i, l.impl_schema = d.s
    WHEN NOT MATCHED THEN
      INSERT (name, impl_schema, impl_name)
      VALUES (d.n, d.s, d.i);
    COMMIT;
  END;

  PROCEDURE remove( p_name              IN log_appender_type.name%TYPE
                   ,throw_if_not_exists IN BOOLEAN DEFAULT TRUE)
  IS
   PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DELETE FROM log_appender_type l
    WHERE l.name    = p_name;
    -- check if we removed something at all
    IF SQL%ROWCOUNT < 1 AND throw_if_not_exists THEN
      util_exception.raise('property_not_found', 'appender ['|| p_name || ']');
    END IF;
    COMMIT;
  END;


END;
/

show error
