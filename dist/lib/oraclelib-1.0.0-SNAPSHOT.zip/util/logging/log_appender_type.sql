PRO Create log appender type table
PRO
/******************************************************************************

  Create log appender registry table.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/log_appender_type.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE TABLE util.log_appender_type(  name         VARCHAR2(20)
                                     ,impl_schema  VARCHAR2(10) NOT NULL
                                     ,impl_name    VARCHAR2(28) NOT NULL
                                     ,CONSTRAINT pk_log_appender_type PRIMARY KEY ( name )
                                   )
/

COMMENT ON TABLE util.log_appender_type IS 'Registration table for log appenders';
COMMENT ON COLUMN util.log_appender_type.name IS 'The log appender type name as referred to in the configuration.';
COMMENT ON COLUMN util.log_appender_type.impl_schema IS 'The log appender object type schema as used by the utility to actually produce the appender.';
COMMENT ON COLUMN util.log_appender_type.impl_name IS 'The log appender object type implementation name as used by the utility to actually produce the appender.';