/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_log_appender
pro
CREATE OR REPLACE PACKAGE util.util_log_appender
IS
/******************************************************************************

  Console Log Appender.

  This Package implements a console log appender.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/util_log_appender_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  28/10/2008  Bertram        Initial Version                         <br>

******************************************************************************/


  -- TOOD: remove TYPE t_appender_settings IS TABLE OF VARCHAR2(300) INDEX BY VARCHAR2(100);


  LEVEL_PROPERTY CONSTANT VARCHAR2(14) := 'appender.level';


  /*{%skip}**********************************************************************
   *
   *
   *  Bla
   *
   *
   ******************************************************************************/

   PROCEDURE register( p_name         IN log_appender_type.name%TYPE
                      ,p_impl_schema  IN log_appender_type.impl_schema%TYPE
                      ,p_impl_name    IN log_appender_type.impl_name%TYPE);

  PROCEDURE remove( p_name              IN log_appender_type.name%TYPE
                   ,throw_if_not_exists IN BOOLEAN DEFAULT TRUE);



  /**

    %param p_category       The log category to add the appender to.
    %param p_name           The unique name of the appender within the log category
    %param p_appender_type  The appender type from log_appender_type
    %param p_level          The level at which the appender should output log messages. <br>
                            If level is NULL, the appender inherits the settings from   <br>
                            the category.

  */
  PROCEDURE add_appender( p_category      IN log_category.name%TYPE
                         ,p_name          IN log_appender.name%TYPE
                         ,p_appender_type IN log_appender.appender_type%TYPE
                         ,p_level         IN log_category.log_level%TYPE DEFAULT NULL);



  /**

    %param p_category       The log category to add the appender to.
    %param p_name           The unique name of the appender within the log category
    %param p_property_name  The name of the appender specific property
    %param p_property_value The property value for the specific appender

  */
  PROCEDURE add_appender_property( p_category       IN log_category.name%TYPE
                                  ,p_name           IN log_appender.name%TYPE
                                  ,p_property_name  IN log_appender.property_name%TYPE
                                  ,p_property_value IN log_appender.property_value%TYPE);



END;
/

show error
