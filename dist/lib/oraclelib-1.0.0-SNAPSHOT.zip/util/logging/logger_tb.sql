/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Type Body logger
pro
CREATE OR REPLACE TYPE BODY util.logger
IS


  MEMBER PROCEDURE severe(self IN OUT NOCOPY Logger, msg IN VARCHAR2)
  IS
  BEGIN
    IF self.is_severe THEN
      util_log.log(msg, self.provided_category, self.effective_category, util_log.SEVERE);
    END If;
  END;

  MEMBER PROCEDURE warn(self IN OUT NOCOPY Logger, msg IN VARCHAR2)
  IS
  BEGIN
    IF self.is_warn THEN
      util_log.log(msg, self.provided_category, self.effective_category, util_log.WARN);
    END If;
  END;

  MEMBER PROCEDURE info(self IN OUT NOCOPY Logger, msg IN VARCHAR2)
  IS
  BEGIN
    IF self.is_info THEN
      util_log.log(msg, self.provided_category, self.effective_category, util_log.INFO);
    END If;
  END;

  MEMBER PROCEDURE debug(self IN OUT NOCOPY Logger, msg IN VARCHAR2)
  IS
  BEGIN
    IF self.is_debug THEN
      util_log.log(msg, self.provided_category, self.effective_category, util_log.DEBUG);
    END If;
  END;

  MEMBER PROCEDURE trace(self IN OUT NOCOPY Logger, msg IN VARCHAR2)
  IS
  BEGIN
    IF self.is_trace THEN
      util_log.log(msg, self.provided_category, self.effective_category, util_log.TRACE);
    END If;
  END;

  MEMBER FUNCTION is_off RETURN BOOLEAN
  IS BEGIN RETURN self.log_level = util_log.OFF;
  END;

  MEMBER FUNCTION is_severe RETURN BOOLEAN
  IS BEGIN RETURN self.is_loggable(util_log.SEVERE);
  END;

  MEMBER FUNCTION is_warn RETURN BOOLEAN
  IS BEGIN RETURN self.is_loggable(util_log.WARN);
  END;

  MEMBER FUNCTION is_info RETURN BOOLEAN
  IS BEGIN RETURN self.is_loggable(util_log.INFO);
  END;

  MEMBER FUNCTION is_debug RETURN BOOLEAN
  IS BEGIN RETURN self.is_loggable(util_log.DEBUG);
  END;

  MEMBER FUNCTION is_trace RETURN BOOLEAN
  IS BEGIN RETURN self.is_loggable(util_log.TRACE);
  END;


  MEMBER FUNCTION is_loggable(p_check_level IN NUMBER) RETURN BOOLEAN
  IS
  BEGIN
    RETURN self.log_level >= p_check_level AND NOT (p_check_level = util_log.OFF OR self.log_level = util_log.OFF);
  END;




  /**


    whats in the logger


  */
  MEMBER FUNCTION get_category RETURN VARCHAR2
  IS
  BEGIN
    RETURN self.provided_category;
  END;

  MEMBER FUNCTION get_level RETURN PLS_INTEGER
  IS
  BEGIN
    RETURN self.log_level;
  END;

  MEMBER PROCEDURE set_level(p_level IN NUMBER)
  IS
  BEGIN
    -- TODO check if valid log level
    self.log_level := p_level;
  END;


  STATIC FUNCTION get_logger(p_category IN VARCHAR2) RETURN Logger
  IS
    /** the loggers effective category */
    --l_effective_category VARCHAR2(100);
    /** the effective log level for the logger */
    --l_level    NUMBER(1,0);

    l_cat util_log.t_category;
  BEGIN
    l_cat := util_log.get_category(p_category);
    -- named cat, effective cat as configured, level as per configuration
    RETURN logger(p_category, l_cat.name, l_cat.lvl);
  END;

END;
/


show errors
