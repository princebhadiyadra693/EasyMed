/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Body util_log
pro
CREATE OR REPLACE PACKAGE BODY util.util_log
IS

  -- the internal logger registry
  g_cat_cache t_categories;


  -- {%skip} prototypes

  FUNCTION get_category(p_category IN log_category.name%TYPE, p_set IN BOOLEAN) RETURN t_category;



  -- {%skip} debug level numeric values
  FUNCTION LVL_OFF    RETURN t_level IS BEGIN RETURN util_log.OFF; END;
  FUNCTION LVL_SEVERE RETURN t_level IS BEGIN RETURN util_log.SEVERE; END;
  FUNCTION LVL_WARN   RETURN t_level IS BEGIN RETURN util_log.WARN; END;
  FUNCTION LVL_INFO   RETURN t_level IS BEGIN RETURN util_log.INFO; END;
  FUNCTION LVL_DEBUG  RETURN t_level IS BEGIN RETURN util_log.DEBUG; END;
  FUNCTION LVL_TRACE  RETURN t_level IS BEGIN RETURN util_log.TRACE; END;

  -- helper function to retrieve the debug level in readable format
  FUNCTION to_char(p_level IN t_level) RETURN VARCHAR2
  IS
  BEGIN
    CASE p_level
      WHEN util_log.OFF         THEN RETURN 'OFF';
      WHEN util_log.SEVERE      THEN RETURN 'SEVERE';
      WHEN util_log.WARN        THEN RETURN 'WARN';
      WHEN util_log.INFO        THEN RETURN 'INFO';
      WHEN util_log.DEBUG       THEN RETURN 'DEBUG';
      WHEN util_log.TRACE       THEN RETURN 'TRACE';
      ELSE util_exception.raise('invalid_log_level', TO_CHAR(p_level));
    END CASE;
  END;


  /**

    Returns True if the category exists in the configuration cache and False otherwise.

  */
  FUNCTION category_exists( p_category IN log_category.name%TYPE) RETURN BOOLEAN
  IS
    l_cat t_category;
  BEGIN
    l_cat := g_cat_cache(p_category);
    IF NOT l_cat.name IS NULL THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN FALSE;
    WHEN OTHERS THEN
      RAISE;
  END;


  /**

    Return the next right from a given string delimited by separation character or <br>
    NULL if no matching separator was found in the string provided.

    Usqage: get_parent('test.me.also') will return 'test.me'

    %param  p_string  The String to extract a parent from.
    %param  p_sep     The separation character used to substring the provided string argument.

   */
  FUNCTION get_parent(p_string VARCHAR2, p_sep CHAR DEFAULT '.') RETURN VARCHAR2
  IS
    l_dotpos      PLS_INTEGER;
  BEGIN
    l_dotpos := instr(p_string, p_sep, -1);
    IF l_dotpos > 0 THEN
      RETURN SubStr(p_string, 0, l_dotpos - 1);
    ELSE
      RETURN NULL;
    END IF;
  END;


  FUNCTION count_nested(cat VARCHAR2, p_sep CHAR DEFAULT '.') RETURN PLS_INTEGER
  IS
    l_dotpos      PLS_INTEGER;
    l_nest_count  PLS_INTEGER := 0;
    l_cat         VARCHAR2(2000) := cat;
  BEGIN
    l_dotpos := instr(l_cat, p_sep, -1);
    WHILE l_dotpos > 0 LOOP
      l_nest_count := l_nest_count + 1;
      l_cat        := SubStr(l_cat, 0, l_dotpos - 1);
      l_dotpos     := instr(l_cat, p_sep, -1);
    END LOOP;
    RETURN l_nest_count;
  END;


  PROCEDURE configure_appenders(p_category_record IN OUT NOCOPY t_category)
  IS
    -- this cursor selects any appender definition with the minimum required log level
    CURSOR c_appenders(v_category IN log_category.name%TYPE) IS
      SELECT la.name
            ,NVL2(lt.impl_schema, NULL, lt.impl_schema || '.') || lt.impl_name AS appender_type
            ,la.category
            ,la.property_name
            ,la.property_value
      FROM   log_appender la
            ,log_appender_type lt
      WHERE  la.appender_type = lt.name
      AND    la.property_name = util_log_appender.LEVEL_PROPERTY --TODO: separate props from logger
      AND    la.category = v_category;

    r_appender c_appenders%ROWTYPE;
    l_appender util.log_appender_abstract;

  BEGIN
    -- get all configured appenders
    OPEN c_appenders(p_category_record.name);
    LOOP
      FETCH c_appenders INTO r_appender;
      EXIT WHEN c_appenders%NOTFOUND;
      -- instantiate implementation type of logger
      EXECUTE IMMEDIATE 'BEGIN :l_appender := '|| r_appender.appender_type ||'(:l_name); END;'
      using OUT l_appender, IN r_appender.name;

      -- set the log level to the one configured
      l_appender.set_level(r_appender.property_value);
      -- retreive all props and call configure on the logger
      DECLARE
        props Properties;
      BEGIN
        SELECT Property(a.property_name, a.property_value)
        BULK COLLECT INTO props
        FROM  util.log_appender a
        WHERE a.name = r_appender.name
        AND   a.category = r_appender.category
        AND   a.property_name != util_log_appender.LEVEL_PROPERTY;
        -- validate and configuer the appender
        l_appender.configure(props);
        l_appender.init;
      EXCEPTION WHEN OTHERS THEN
        -- TODO what to do when logger fails?
        NULL;
      END;
      -- add appender to category loggers
      p_category_record.appenders(p_category_record.appenders.COUNT + 1) := l_appender;
    END LOOP;
    CLOSE c_appenders;

  EXCEPTION WHEN NO_DATA_FOUND THEN
    -- TODO: need to do something with it? Also close the cursor !!
    NULL;
  END;






  FUNCTION get_category(p_category IN log_category.name%TYPE) RETURN t_category
  IS
  l_cat t_category;
  l_cat_copy t_category;
  BEGIN
    l_cat := get_category(p_category, TRUE);
    /*
    -- IF p_cat aint match with l_Cat.name
    IF l_cat.name != p_category THEN
      -- duplicate l_cat
      l_cat_copy.name := p_category;
      l_cat_copy.effective_name := l_cat.name;
      l_cat_copy.lvl := l_cat.lvl;
      l_cat_copy.appenders := l_cat.appenders;
      -- add to cache with p_cat
      g_cat_cache(p_category) := l_cat_copy;
      RETURN l_cat_copy;
    ELSE
      RETURN l_cat;
    END IF;
    */
    RETURN l_cat;
  END;

  FUNCTION get_category(p_category IN log_category.name%TYPE, p_set IN BOOLEAN) RETURN t_category
  IS
  BEGIN
    /*
      if category already exists in cache
        grab logger configuration
      else
        check configuration in the database
        if configuration exsists for this category then
          load category configuration in cache and return with it
        else
          if category has parent then
            recurse parent
          else
            return root logger configuration
          end if
        end if
      end if
    */
    -- TODO: set effective here ...
    RETURN g_cat_cache(p_category);

  EXCEPTION WHEN NO_DATA_FOUND THEN
    -- oops category is not in the cache
    -- try to find it in the configuration and add it to the cache
    DECLARE
      l_cc  t_category;
      l_lvl log_category.log_level%TYPE;
    BEGIN
      -- TODO: index on log_appender.category
      SELECT c.log_level
      INTO   l_lvl
      FROM   log_category c
      WHERE  c.name = p_category;

      -- can configure the effective category and level but since recursive might need to configure real name later
      l_cc.name := p_category;
      l_cc.lvl := l_lvl;

      -- store all log appenders with it
      configure_appenders(l_cc);

      -- also ensure its in the cache
      g_cat_cache(p_category) := l_cc;

      RETURN l_cc;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      -- no configuration in cache or database, go and work it out recursively
      DECLARE
        l_parent_cat log_category.name%TYPE;
      BEGIN
        l_parent_cat := get_parent(p_category);
        -- if it has parent process
        IF l_parent_cat IS NOT NULL THEN
          RETURN get_category(l_parent_cat, FALSE);
        ELSE
          -- else return root
          -- TODO: if root logger was nuked fail misserably
          RETURN get_category(util_log.ROOT_LOGGER_NAME, FALSE);
        END IF;
      END;
    END;
  END;



  FUNCTION create_properties RETURN Properties
  IS
  BEGIN
    -- TODO: implement
    RETURN NULL;
  END;














  /**


    If ever need to fix also fix in Logger !!!
  */
  FUNCTION is_loggable( p_set_level   IN t_level
                       ,p_check_level IN t_level) RETURN BOOLEAN
  IS
  BEGIN
    RETURN p_set_level >= p_check_level AND NOT (p_check_level = util_log.OFF OR p_set_level = util_log.OFF);
  END;


  FUNCTION is_loggable( p_category    IN log_category.name%TYPE
                       ,p_check_level IN t_level) RETURN BOOLEAN
  IS
    l_set_level t_level;
  BEGIN
  -- TODO: change to read effective configuration not the default ... this includes comparing the logger value with the actual set one
    SELECT log_level
    INTO   l_set_level
    FROM   log_category lc
    WHERE  lc.name = p_category;

    -- TODO: implement
    RETURN is_loggable(l_set_level, p_check_level);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      util_exception.raise('uninitialised', p_category || ' category');
  END;



  /*{%skip}**********************************************************************
   *
   *
   *  Debug Setting Managment.
   *
   *
   ******************************************************************************/

  FUNCTION get_level(p_category IN log_category.name%TYPE) RETURN t_level
  IS
    l_level log_category.log_level%TYPE;
  BEGIN
    SELECT lc.log_level
    INTO l_level
    FROM log_category lc
    WHERE lc.name = p_category;

    RETURN l_level;
  END;

  FUNCTION gets_level(p_category IN log_category.name%TYPE) RETURN VARCHAR2
  IS
  BEGIN
    RETURN to_char(get_level(p_category));
  END;


  -- Set the application debug level for a specified application.
  PROCEDURE set_level( p_category IN log_category.name%TYPE
                      ,p_level    IN t_level)
  IS
  BEGIN
    IF p_level > util_log.TRACE THEN
      RAISE_APPLICATION_ERROR(-20050, 'Debug level is too large.');
    ELSIF p_level < util_log.OFF THEN
      RAISE_APPLICATION_ERROR(-20050, 'Debug level is too small.');
    END IF;
    -- TODO: store it
  END;



  /*{%skip}**********************************************************************
   *
   *
   *  Application Logging
   *
   *
   ******************************************************************************/

  /**

    Log a message to the application log table if the application log level is set
    for the corresponding log level or higher.

  */
  PROCEDURE log( p_msg                  IN VARCHAR2
                ,p_category             IN log_category.name%TYPE
                ,p_effective_category   IN log_category.name%TYPE   DEFAULT NULL
                ,p_level                IN util_log.t_level         DEFAULT util_log.SEVERE
                ,p_type                 IN VARCHAR2                 DEFAULT 'database'
                ,p_large_msg            IN CLOB                     DEFAULT NULL)
  IS
    l_cat             t_category;
  BEGIN
    -- TODO: get_category misserably fails if root is nuked ...
    l_cat := get_category( NVL(p_effective_category, p_category) );

    -- if log level loggable then
    IF is_loggable(l_cat.lvl, p_level) THEN
      -- TODO: store it
      DECLARE
        i PLS_INTEGER;
        l_appender log_appender_abstract;
      BEGIN

        -- TODO: appenders could be NULL
        i := l_cat.appenders.FIRST;
        LOOP
          EXIT WHEN i IS NULL;
          l_appender := l_cat.appenders(i);
          IF is_loggable(l_appender.get_level, p_level) THEN
            -- log without breaking other logs
            BEGIN
              l_appender.write_log(p_category, util_log.to_char(p_level),  p_msg);
            EXCEPTION
              WHEN OTHERS THEN
                -- TODO: write out a std warning
                NULL;
            END;
          END IF;
          i := l_cat.appenders.NEXT(i);
        END LOOP;

      END;
    END IF;

  END;


  /**

    Registers a logger category.

   */
  PROCEDURE register( p_category       IN log_category.name%TYPE
                     ,p_default_level  IN t_level)
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_dummy CHAR(1);
  BEGIN
    SELECT '1'
    INTO l_dummy
    FROM log_category lc
    WHERE lc.name = p_category;
    -- spit dummy already registered
    util_exception.raise('already_initialised', p_category || ' category');
  EXCEPTION WHEN no_data_found THEN
    INSERT INTO log_category(name, log_level)
    VALUES (p_category, p_default_level);
    COMMIT;
  END;

  /**

    Adds the appender to the registry.
    Should only be called by your custom appenders init method.

   */
  PROCEDURE register_appender( p_name IN log_appender.name%TYPE)
  IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_dummy CHAR(1);
  BEGIN
    SELECT '1'
    INTO l_dummy
    FROM log_appender la
    WHERE la.name = p_name;
    util_exception.raise('already_initialised', p_name || ' log appender');
  EXCEPTION WHEN no_data_found THEN
    INSERT INTO log_appender(name)
    VALUES (p_name);
    COMMIT;
  END;

END util_log;
/


show error
