/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Package Spec util_log
pro
CREATE OR REPLACE PACKAGE util.util_log
IS
/******************************************************************************

  Common Logging Package.

  This Package provides essential logging features.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/util_log_ps.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %usage    To configure the application following needs to be run:

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  19/09/2004  Bertram        Initial Version                         <br>

******************************************************************************/

  -- log level type
  SUBTYPE t_level IS NUMBER(1,0);

  -- TODO: move into the body ? no need to be visible

  -- a collection of instatiated log appenders
  TYPE t_appenders IS TABLE OF util.log_appender_abstract NOT NULL INDEX BY BINARY_INTEGER;

  -- the instantiated logging category
  TYPE t_category IS RECORD ( name            log_category.name%TYPE
                             ,lvl             util_log.t_level
                             ,appenders       util_log.t_appenders);

  -- the global cache of configured categories and their respective loggers
  TYPE t_categories IS TABLE OF t_category NOT NULL INDEX BY VARCHAR2(100);

  ROOT_LOGGER_NAME CONSTANT VARCHAR2(10) := 'root';


  /* {%skip}

    All available debug levels (need to be fx so we can call them from the forms package).
    Please note that the numbers for the log levels are sparce so that one can introduce
    log levels in between for a more fine grain logging control. But be wise about the new
    log levels. There is nothing from my point of view that needs to be added currently.

  */

  -- Do not log any log messages
  OFF         CONSTANT t_level := 0;
  -- Only log severe log messages
  SEVERE      CONSTANT t_level := 1;
  -- Only log messages that are warning and above.<br>(e.g. log only severe and warn log messages)
  WARN        CONSTANT t_level := 3;
  -- Only log messages that are info and above
  INFO        CONSTANT t_level := 5;
  -- Only log messages that are debug and above
  DEBUG       CONSTANT t_level := 8;
  -- Log all messages
  TRACE       CONSTANT t_level := 9;

  -- {%skip} All available debug levels (need to be functions so they can be called from forms packages)
  FUNCTION LVL_OFF    RETURN t_level;
  FUNCTION LVL_SEVERE RETURN t_level;
  FUNCTION LVL_WARN   RETURN t_level;
  FUNCTION LVL_INFO   RETURN t_level;
  FUNCTION LVL_DEBUG  RETURN t_level;
  FUNCTION LVL_TRACE  RETURN t_level;


  -- helper function to retrieve the debug level in readable format
  FUNCTION to_char(p_level IN t_level) RETURN VARCHAR2;


  /* {%skip}

  General Logger design

  A logger can be specified by name
    -- 1 default root logger is configured with util that appends by default to the console (dbms_output)


    -- a logger can be associated with a particular category (default sorting as per . convention)

   Log Category Configuration
   -------------------------------------------------------
   category.bla.bla=DEBUG

   Appender Type
   -------------------------------------------------------
   name1 [type_name]
   name2 [type_name]
   name3 [type_name]

   Appender Configuration
   -------------------------------------------------------
   [appender-name] [appender-type] [category1] [level]=[value]
   [appender-name] [appender-type] [category1] [property1]=[value]
   [appender-name] [appender-type] [category1] [property2]=[value]

   [appender-name] [appender-type] [category2] [level]=[value]
   [appender-name] [appender-type] [category2] [property1]=[value]
   ...


   application
      |
      +--- category1:INFO
      |         |
      |         +--- stdout:console:SEVERE
      |         |      |
      |         |      +--- property1:value
      |         |      |
      |         |      +--- property2:value
      |         |
      |         +--- another:log-table:WARN
      |         |      |
      |         |      +--- property1:value
      |         |      |
      |         |      +--- property2:value
      |         |      |
      |         |      +--- property3:value
      |         |      |
      |         |      +--- property4:value
      |         |
      |         +--- monimal:console:INFO
      |         |      |
      |         |      +--- property1:value
      |
      +--- category2 SEVERE
                |
                +--- ...


  should happen statically in the package body (preferrably as constant)
  log Logger := logger.create_logger('my.category');

  IF log.is_debug THEN
    log.debug('bla bla');
  END IF;

  if log.is_debug is called, the logger checks it's private log level and returns.

  if it gets requested to log a category a simple associative lookup gets the log config / level
  and queries the appenders and invokes them.


  create logger will call util_log

  if category already exists in cache
    grab logger configuration
  else
    check configuration in the database
    if configuration exsists for this category then
      load category configuration in cache and return with it
    else
      if category has parent then
        recurse parent
      else
        return root logger configuration
      end if
    end if
  end if

  */




  -- only exposed when unit testing is enabled ...
  &ut_start
  FUNCTION count_nested(cat VARCHAR2, p_sep CHAR DEFAULT '.') RETURN PLS_INTEGER;
  &ut_end


  /**

    Return the effective category configuration for a given category (i.e. the one that is actually configured).


  */
  FUNCTION get_category(p_category IN log_category.name%TYPE) RETURN t_category;


  /**

    Get the log level configured for a given category.

    %param p_category The category name.

    %return The log level for the provided category as configured in the log category settings.

    %usage To check a category level string query as followed.<br>
           SQL> SELECT util_log.get_log_level('my.category') FROM dual;

  */
  FUNCTION get_level(p_category IN log_category.name%TYPE) RETURN t_level;


  /**

    Get the log level configured for a given category.

    %param p_category The category name.

    %return A string representation of the log setting.

    %usage To check a category level string query as followed.<br>
           SQL> SELECT util_log.gets_log_level('my.category') FROM dual;

  */
  FUNCTION gets_level(p_category IN log_category.name%TYPE) RETURN VARCHAR2;

  /**

    Set the application debug level for a specified application.

    %param p_application The application name.
    %param p_level the debug level to be set for the application

    %usage To set the apllication debug level for a particular application one can issue
           following statement.<br>
           SQL> exec util_log.set_application_debug_level('SSS', util_log.FULL);

  */
  PROCEDURE set_level( p_category IN log_category.name%TYPE
                      ,p_level    IN t_level);


  FUNCTION is_loggable( p_set_level   IN t_level
                       ,p_check_level IN t_level) RETURN BOOLEAN;

  FUNCTION is_loggable( p_category    IN log_category.name%TYPE
                       ,p_check_level IN t_level) RETURN BOOLEAN;


  FUNCTION category_exists( p_category IN log_category.name%TYPE) RETURN BOOLEAN;


  /*{%skip}**********************************************************************
   *
   *
   *  A collection logging features.
   *
   *
   ******************************************************************************/

  /**

    TODO: Log a message to the application log table if the application log level is set
    for the corresponding log level or higher.
    By default the log record is deemed to be a database type log record with a
    util_log.SEVERE log level. If the developer wants to log other messages
    s/he will need to explicitly code a particular level.

    %param p_msg          The log message to log.
    %param p_application  The name of the application logging.
    %param p_level        The log level severity.
    %param p_type         The type of log.
    %param p_large_msg    Optional a large text clob. e.g. forms message stack.

    %usage EXEC util_log.log('test 123', 'SSS');<br>
           Will log a severe message for SSS application<br>
           <br>
           EXEC util_log.log('test 123', 'LRP', util_log.DEBUG);<br>
           Will log a debug message for LRP application, or if the application
           level is set to util_log.WARN, no log will be created.<br>
           <br>
           EXEC util_log.log('some message', 'SSS', util_log.DEBUG, 'forms', 'my stack');<br>
           Will log a debug message for SSS forms application and include my stack data.
  */
  PROCEDURE log( p_msg                  IN VARCHAR2
                ,p_category             IN log_category.name%TYPE
                ,p_effective_category   IN log_category.name%TYPE   DEFAULT NULL
                ,p_level                IN util_log.t_level         DEFAULT util_log.SEVERE
                ,p_type                 IN VARCHAR2                 DEFAULT 'database'
                ,p_large_msg            IN CLOB                     DEFAULT NULL);


  PROCEDURE register( p_category       IN log_category.name%TYPE
                     ,p_default_level  IN t_level);

END util_log;
/

show error
