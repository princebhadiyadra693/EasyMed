/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Type Body log_appender_log4j
pro
CREATE OR REPLACE TYPE BODY util.log_appender_log4j
IS

  CONSTRUCTOR FUNCTION log_appender_log4j(name IN VARCHAR2) RETURN self AS RESULT
  IS
  BEGIN
    self.name := name;
    RETURN;
  END;

  /**
    Write the log message
   */
  OVERRIDING MEMBER PROCEDURE write_log(category IN VARCHAR2, lvl IN VARCHAR2, msg IN VARCHAR2)
  IS
    /** the actual socket connection to the log server */
    cnn utl_tcp.connection;
    ret_val PLS_INTEGER;
  BEGIN
    dbms_output.put_line( sprintf('%s [%s] %s [%s:%s:%s] -> %s', category, RPAD(LOWER(lvl), 6), TO_CHAR(SYSDATE, 'CCYY-MM-DD HH24:MI:SS'), RPAD(self.name, 6), self.host, TO_CHAR(self.port), msg ) );

    -- TODO check if port and host are valid ...
    cnn     := utl_tcp.open_connection(remote_host => self.host, remote_port => self.port, charset => 'UTF-8'); -- open connection
    ret_val := utl_tcp.write_text(cnn, '<log4j:event logger="' || category || '" timestamp="' ||TO_CHAR(util_temporale.get_unix_timestamp) || '" sequenceNumber="85" level="' || lvl || '" thread="session x">');
    ret_val := utl_tcp.write_text(cnn, '<log4j:message><![CDATA[' || msg || ']]></log4j:message>');
    ret_val := utl_tcp.write_text(cnn, '</log4j:event>');

      --ret_val := utl_tcp.write_line(cnn, UTL_TCP.CRLF);
    utl_tcp.flush(cnn);
    utl_tcp.close_connection(cnn);
  EXCEPTION
    WHEN OTHERS THEN
      -- just make sure connection is closed  ...
      BEGIN utl_tcp.close_connection(cnn); EXCEPTION WHEN OTHERS THEN NULL; END;
      RAISE;
  END;

  OVERRIDING MEMBER PROCEDURE configure(p_properties IN Properties)
  IS
  BEGIN
    -- TODO: call super
    --this does not work in 10g and below --> ((self AS util.log_appender_abstract)).configure(p_properties);

    -- then process whatever I need
    -- TODO: format mask for the output
    FOR i IN 1 .. p_properties.count LOOP
      IF p_properties(i).name IS NOT NULL THEN
        dbms_output.put_line(sprintf('processing %s - %s=%s', i, p_properties(i).name, p_properties(i).value) );

        IF p_properties(i).name = 'log4j.host' THEN
          self.host := p_properties(i).value;
        ELSIF p_properties(i).name = 'log4j.port' THEN
          self.port := p_properties(i).value;
        END IF;
      END IF;
    END LOOP;
  END;



END;
/


show errors
