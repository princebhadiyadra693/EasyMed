/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Type Spec log_appender_console
pro
CREATE OR REPLACE TYPE util.log_appender_console UNDER util.log_appender_abstract
(
/******************************************************************************

  Console Log Appender

  A log appender that writes log messages to the console.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/log_appender_console_ts.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %usage    To configure the application following needs to be run:

  %$Revision: 1 $

  %Revisions:
  Ver   Date        Author         Description                             <br>
  ----  ----------  -------------  -------------------------------------   <br>
   1.0  19/09/2008  Bertram        Initial Version                         <br>

******************************************************************************/

   CONSTRUCTOR FUNCTION log_appender_console(name IN VARCHAR2) RETURN self AS RESULT

  ,OVERRIDING MEMBER PROCEDURE write_log(category IN VARCHAR2, lvl IN VARCHAR2, msg IN VARCHAR2)

  ,OVERRIDING MEMBER PROCEDURE write_log(category IN VARCHAR2, lvl IN VARCHAR2, msg IN OUT NOCOPY CLOB)

) NOT FINAL;
/

show errors
