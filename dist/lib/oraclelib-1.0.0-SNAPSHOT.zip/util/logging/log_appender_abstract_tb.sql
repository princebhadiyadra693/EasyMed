/******************************************************************************

  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

******************************************************************************/
pro Compile Type Body log_appender_abstract
pro
CREATE OR REPLACE TYPE BODY util.log_appender_abstract
IS


  CONSTRUCTOR FUNCTION log_appender_abstract(p_name IN VARCHAR2) RETURN self AS RESULT
  IS
  BEGIN
    self.name := p_name;
    RETURN;
  END;

  MEMBER FUNCTION get_level RETURN NUMBER
  IS
  BEGIN
    RETURN self.threshold;
  END;

  MEMBER PROCEDURE set_level(loglevel IN NUMBER)
  IS
  BEGIN
    self.threshold := loglevel;
  END;


  /**
    Write the log message
   */
  MEMBER PROCEDURE write_log(category IN VARCHAR2, lvl IN VARCHAR2, msg IN VARCHAR2)
  IS
  BEGIN
    NULL;
  END;

  MEMBER PROCEDURE write_log(category IN VARCHAR2, lvl IN VARCHAR2, msg IN OUT NOCOPY CLOB)
  IS
  BEGIN
    NULL;
  END;


  MEMBER PROCEDURE init
  IS
  BEGIN
    NULL;
  END;

  MEMBER PROCEDURE configure(p_properties IN Properties)
  IS
  BEGIN
    NULL;
  END;

END;
/


show errors
