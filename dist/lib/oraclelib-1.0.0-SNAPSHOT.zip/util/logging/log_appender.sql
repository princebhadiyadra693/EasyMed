PRO Create log_appender table
PRO
/******************************************************************************

  Create log appender configuration table.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util/logging/log_appender.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE TABLE util.log_appender( name                VARCHAR2(100)
                               ,appender_type       VARCHAR2(100)
                               ,category            VARCHAR2(100) -- TODO: log_category.name%TYPE
                               ,property_name       VARCHAR2(100)
                               ,property_value      VARCHAR2(100)
                               ,CONSTRAINT pk_log_appender PRIMARY KEY ( name, category, property_name ) -- each appender is unique per category
                               ,CONSTRAINT fk_appender_type FOREIGN KEY (appender_type) REFERENCES util.log_appender_type(name)
                               ,CONSTRAINT fk_appender_category FOREIGN KEY (category) REFERENCES util.log_category(name)
                              )
/

COMMENT ON TABLE util.log_appender IS 'configuration table for log appenders for each category';
COMMENT ON COLUMN util.log_appender.name IS 'The log appender instance name.';
COMMENT ON COLUMN util.log_appender.appender_type IS 'The log appender type name.';
COMMENT ON COLUMN util.log_appender.property_name IS 'Appender configuration name value pairs.';
COMMENT ON COLUMN util.log_appender.property_value IS 'Appender configuration name value pairs.';
