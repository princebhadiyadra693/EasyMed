/******************************************************************************

  Creates the utils user and a developer role that can be used to trace and
  debug database sessions.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/sys/create_user.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/
set verify off

pro Create developer role
-- create a role that can use trace and debug facilities
CREATE ROLE developer
/

pro Create util owner
-- create the utilities user
CREATE USER util IDENTIFIED BY &pwd_util
                 ACCOUNT LOCK
                 DEFAULT TABLESPACE &tablespace_user
                 TEMPORARY TABLESPACE &tablespace_temp
/

set verify on