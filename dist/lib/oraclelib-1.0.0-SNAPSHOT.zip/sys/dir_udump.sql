/******************************************************************************

  Creates the user dump descriptor in the database.

  %Note       If the user dump is changed in the ora init, it will break the
              trace util unless this dir is altered to point to the new
              location.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/sys/dir_udump.sql $

  %RunAs:     SYSDBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/
set feedback off
set termout off

undefine udump_dir
undefine dir
column udump_dir new_val dir nopri

SELECT pr.value AS udump_dir
FROM v$parameter pr
WHERE pr.name = 'user_dump_dest'
/

set verify off
set feedback on
set termout on
pro Creating User DUMP directory descriptor as &dir ...
CREATE OR REPLACE DIRECTORY udump_dir AS '&dir'
/

set verify on
