PRO
PRO **************************************************************************
PRO Install UTIL User Setup
PRO
/******************************************************************************

  Create the utility user and a developer role.

  The util user owns all utility packages and requires some high sys grants
  directly to be able to expose these through the packages. The developer role
  is thought to be a proxy role that allows actual users to utilise
  functionality of the util.

  All generally usefull utilities are exposed publicly with a public synonym
  and relevant privileges granted to public.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/1_util_setup.sql $

  %RunAs:     SYSDBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

set VERIFY OFF
--
-- CONFIGURE
--
-- Revise if this is the tablespaces you want util to be installed !!
--
DEFINE tablespace_user=users
DEFINE tablespace_temp=temp
DEFINE pwd_util=util

/**
 * Configuration section for unit testing.
 * 
 * If the ut_flat is not set to Y the unit tests will not run !!!!
 */
DEFINE ut_flag=Y
COLUMN col1 NOPRINT NEW_VALUE ut_start
COLUMN col2 NOPRINT NEW_VALUE ut_end

SELECT DECODE('&ut_flag' ,'Y', '/** start unit testing exposure */', '/* only exposed for ut ') AS col1
      ,DECODE('&ut_flag' ,'Y', '/** end unit testing exposure */', ' end ut */') AS col2
FROM dual
/

@sys/create_user.sql

@sys/dir_udump.sql

@1_grants.sql

@1_synonyms.sql
