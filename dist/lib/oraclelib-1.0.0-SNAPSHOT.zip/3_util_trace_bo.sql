PRO
PRO **************************************************************************
PRO Remove Trace Utils
PRO
/******************************************************************************

  Deinstalls trace utilities.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/3_util_trace_bo.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

DROP TABLE util.traces CASCADE CONSTRAINTS
/

DROP PUBLIC SYNONYM util_trace
/

DROP PACKAGE util.util_trace
/

