PRO
PRO **************************************************************************
PRO Install UTIL User Grants
PRO
/******************************************************************************

  Grants various privs to the developer role and utils owner.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/1_grants.sql $

  %RunAs:     SYSDBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

-- need to see v$session, v$process and v$instance for tracing and debugging
GRANT DEBUG CONNECT SESSION TO developer
/

-- needed to see session info
GRANT SELECT ON sys.v_$session TO developer
/

-- needs to own some objects at least resource
GRANT RESOURCE TO util
/

-- Utils is a developer in fact but we need the grants direct as we will referrence
-- the views from within PL/SQL package and can not have priv set through a role
-- at compile time.

-- needed to get session info
GRANT SELECT ON sys.v_$session TO util
/

-- needed to get oracle session process id to construct trace file name
GRANT SELECT ON sys.v_$process TO util
/

-- to make sure we trace the right instance in a potential cluster
GRANT SELECT ON sys.v_$instance TO util
/

-- in case the trace file prefix was changed in the init
GRANT SELECT ON sys.v_$parameter TO util
/

-- should normally come with plustrace ?!
GRANT SELECT ON sys.v_$mystat TO util
/

-- used in wrapper PL/SQL package to set session trace level
GRANT EXECUTE ON sys.dbms_system TO util
/

-- used in wrapper PL/SQL package to send email
GRANT EXECUTE ON sys.utl_tcp TO util
/

-- used in wrapper PL/SQL package to send email
GRANT EXECUTE ON sys.utl_smtp TO util
/

-- used in wrapper PL/SQL package to send email
GRANT EXECUTE ON sys.utl_tcp TO util
/

-- make sure we can read the udump folder
GRANT READ ON DIRECTORY sys.udump_dir TO util
/