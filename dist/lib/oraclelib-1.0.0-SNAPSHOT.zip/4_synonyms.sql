PRO
PRO **************************************************************************
PRO Install Application Utils Synonyms
PRO
/******************************************************************************

  Creates public synonyms for application util packages and tables.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/4_synonyms.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE PUBLIC SYNONYM util_exception FOR util.util_exception
/


CREATE PUBLIC SYNONYM util_conf FOR util.util_conf
/

CREATE PUBLIC SYNONYM Property FOR util.Property
/

CREATE PUBLIC SYNONYM Properties FOR util.Properties
/


CREATE PUBLIC SYNONYM util_email FOR util.util_email
/

CREATE PUBLIC SYNONYM util_log FOR util.util_log
/

CREATE PUBLIC SYNONYM util_log_appender FOR util.util_log_appender
/

-- only make the implementation of the log appenders visible
CREATE PUBLIC SYNONYM log_appender_console FOR util.log_appender_console
/

CREATE PUBLIC SYNONYM log_appender_log4j FOR util.log_appender_log4j
/

