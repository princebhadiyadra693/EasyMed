PRO
PRO **************************************************************************
PRO Install Application Util Grants
PRO
/******************************************************************************

  Grants various privs on application util resources.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/4_grants.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

-- anone should be able to call exception raising facilities
GRANT EXECUTE ON util.util_exception TO PUBLIC
/

-- developer should be able to manage exceptions configured (alternative alter to allow dba group to manage only)
GRANT SELECT ON util.exceptions TO developer
/

-- just defined types ...
GRANT EXECUTE ON util.Property TO PUBLIC
/

GRANT EXECUTE ON util.Properties TO PUBLIC
/

-- configuration settings should only be managable by developer
GRANT EXECUTE ON util.util_conf TO developer
/

-- only let developers select settings but should manage through the util_conf api
GRANT SELECT ON util.settings TO developer
/

-- anone should be able to send email
GRANT EXECUTE ON util.util_email TO PUBLIC
/

-- TODO: anyone should be able to initiate logging
GRANT EXECUTE ON util.util_log TO PUBLIC
/

GRANT EXECUTE ON util.util_log_appender TO PUBLIC
/

-- TODO: review as abstract is not instantiable
GRANT EXECUTE ON util.log_appender_abstract TO PUBLIC
/

-- allow execution on the implementation of the log appenders
GRANT EXECUTE ON util.log_appender_console TO PUBLIC
/

-- allow execution on the log4j xml appender
GRANT EXECUTE ON util.log_appender_log4j TO PUBLIC
/


-- developer can manage stylesheets but no need to mke it public
GRANT SELECT, INSERT, UPDATE, DELETE ON util.stylesheet TO developer
/