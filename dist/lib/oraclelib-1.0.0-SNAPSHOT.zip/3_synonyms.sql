PRO
PRO **************************************************************************
PRO Install Trace Synonyms
PRO
/******************************************************************************

  Creates public synonyms for trace util packages and tables.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/3_synonyms.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE PUBLIC SYNONYM util_trace FOR util.util_trace
/


