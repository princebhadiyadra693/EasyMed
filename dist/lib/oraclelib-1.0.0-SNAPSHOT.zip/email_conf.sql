exec util_conf.set(util_email.CONF_EMAIL_ENABLED, TRUE, util_email.CONF_EMAIL_SECTION);

exec util_conf.set(util_email.CONF_EMAIL_HOST, 'smtp.xxx.com', util_email.CONF_EMAIL_SECTION);

exec util_conf.set(util_email.CONF_EMAIL_PORT, 587, util_email.CONF_EMAIL_SECTION);

exec util_conf.set(util_email.CONF_EMAIL_DOMAIN, 'xxx.com', util_email.CONF_EMAIL_SECTION);

exec util_conf.set(util_email.CONF_EMAIL_SSL_ENABLED, TRUE, util_email.CONF_EMAIL_SECTION);

exec util_conf.set(util_email.CONF_EMAIL_SSL_USER, 'niels.bertram@xxx.com', util_email.CONF_EMAIL_SECTION);

exec util_conf.set(util_email.CONF_EMAIL_SSL_PWD, 'xxx', util_email.CONF_EMAIL_SECTION);
