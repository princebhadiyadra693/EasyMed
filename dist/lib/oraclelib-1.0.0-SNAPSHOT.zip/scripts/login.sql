/******************************************************************************

  Global login script.

  A script to customise the login prompt of SQL*Plus. This script needs to live
  in the SQLPATH to be processed by SQL*Plus.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/scripts/login.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/
col column_name format a30
col sql_text format a64
col segment_name format a40 trunc
col object_name format a40 trunc
col tablespace_name format a20 trunc
col username format a20 trunc
col program format a30 trunc
SET lines 119
SET pages 99
SET ROLE ALL

SET trimspool ON

SET serveroutput ON

COLUMN what format a50 word_wrapped
COLUMN plan_plus_exp format a100
SET termout OFF
col loguser new_value gname nopri
SELECT lower(user || '@' || global_name) "loguser" FROM global_name;
SET termout ON
SET sqlprompt '&&gname> '
DEFINE _EDITOR="C:\Program Files\TextPad\TextPad.exe"
