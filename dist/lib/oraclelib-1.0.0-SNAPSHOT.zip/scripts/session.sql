/******************************************************************************

  Session information.

  This script shows current sessions at the database.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/scripts/session.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/
set termout off
store set c:\temp\.sqlplus_backup replace
clear breaks
clear columns
clear computes
set feedback off
set verify off
set termout on
set wrap on

col sid justify center format 999
col pid justify center format 99999
col spid justify center format 99999
col serial justify center format 99999
col username format a10 trunc
col osuser format a10 trunc
col machine format a10 trunc
col program format a15 trunc
col module format a20
col action format a16 trunc
col client_info format a12 trunc
col client_identifier format a14 trunc
SET lines 119
SET pages 0
set embedded on
set linesize 4000
set trimspool on
set verify off

SELECT p.spid               -- Oracle session process thread id
      --,p.pid                -- Oracle db kernel thread id (on windows not the actual process id)
      --,s.process            -- user process:thread
      ,s.sid                -- internal Oracle db session id
      ,s.serial# AS serial  --
      ,s.username
      ,CASE WHEN instr(s.osuser,'\') = 0 THEN
         s.osuser
       ELSE
         SUBSTR(s.osuser, instr(s.osuser, '\')+1)
       END AS osuser
      ,CASE WHEN instr(s.machine,'\') = 0 THEN
         lower(s.machine)
       ELSE
         lower(SUBSTR(s.machine, instr(s.machine, '\')+1))
       END AS machine
      ,s.program
      ,s.module
      ,s.action
      ,s.client_info
      ,s.client_identifier
 FROM  v$session s
      ,v$process p
WHERE  s.paddr = p.addr
AND    s.username IS NOT NULL
AND    s.username NOT IN ('ANONYMOUS')
/

clear breaks
clear columns
clear computes

set termout off
@c:\temp\.sqlplus_backup
set termout on
