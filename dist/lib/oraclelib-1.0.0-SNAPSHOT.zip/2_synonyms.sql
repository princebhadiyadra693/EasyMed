PRO
PRO **************************************************************************
PRO Install Core Synonyms
PRO
/******************************************************************************

  Creates public synonyms for core util packages and procedures.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/2_synonyms.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

CREATE PUBLIC SYNONYM logger FOR util.logger
/

CREATE PUBLIC SYNONYM util_locale FOR util.util_locale
/

CREATE PUBLIC SYNONYM util_lob FOR util.util_lob
/

CREATE PUBLIC SYNONYM util_temporale FOR util.util_temporale
/

CREATE PUBLIC SYNONYM util_string FOR util.util_string
/

CREATE PUBLIC SYNONYM sprintf FOR util.sprintf
/

CREATE PUBLIC SYNONYM util_xml FOR util.util_xml
/


-- Aggregation Functions

CREATE PUBLIC SYNONYM t_aggexp FOR util.t_aggexp
/

CREATE PUBLIC SYNONYM aggstr FOR util.aggstr
/

CREATE PUBLIC SYNONYM aggstr_distinct FOR util.aggstr_distinct
/

CREATE PUBLIC SYNONYM aggstr_exp FOR util.aggstr_exp
/

CREATE PUBLIC SYNONYM aggclob FOR util.aggclob
/

CREATE PUBLIC SYNONYM aggclob_exp FOR util.aggclob_exp
/


