CLEAR SCREEN
SET TERMOUT OFF
SET ECHO OFF
SET VERIFY OFF
SET FEEDBACK OFF 
SET TTITLE OFF
SET SERVEROUTPUT ON SIZE 1000000 FORMAT WRAPPED
SET DEFINE ON

----------------------------------------------------
-- Oracle Library Installer
--
-- parameter 1 values:
--
--  prepare   - prepare the user account and privs
--  install   - install library
--  reinstall - re-install library
--  uninstall - un-install library
----------------------------------------------------

DEFINE line1='----------------------------------------------------------------'
DEFINE line2='________________________________________________________________'
DEFINE finished='.                            Finished'

COLUMN col NOPRINT NEW_VALUE lib_owner
select USER col from dual;

COLUMN col NOPRINT NEW_VALUE install_action
select decode( LOWER('&1'),'install','util_install'
                          ,'uninstall','util_uninstall'
                          ,'reinstall','util_reinstall'
                          ,'prepare','util_setup'                          
                          ,'ERROR') col from dual;


                          -- TODO: 2nd arg is either nothing or module name
--  validate only modules supplied ...
COLUMN col NOPRINT NEW_VALUE install_module
SELECT CASE WHEN '&2' IN ('core', 'trace', 'application') THEN '&2'
       WHEN '&2' IS NULL THEN 'all'
       ELSE 'ERROR'
       END col
FROM dual;

COLUMN col NOPRINT NEW_VALUE txt_prompt
select decode('&install_action','util_install','I N S T A L L A T I O N'
                            ,'util_uninstall','D E I N S T A L L A T I O N'
                            ,'util_reinstall','R E I N S T A L L A T I O N'
                            ,'util_setup','S E T U P  U T I L'
                            ,'ERROR') col from dual;

------------------------------------------------------

SET TERMOUT ON

PROMPT &line2
PROMPT 
PROMPT   Licensed to the Apache Software Foundation (ASF) under one or more
PROMPT   contributor license agreements.  See the NOTICE file distributed with
PROMPT   this work for additional information regarding copyright ownership.
PROMPT   The ASF licenses this file to You under the Apache License, Version 2.0
PROMPT   (the "License"); you may not use this file except in compliance with
PROMPT   the License.  You may obtain a copy of the License at
PROMPT 
PROMPT       http://www.apache.org/licenses/LICENSE-2.0
PROMPT 
PROMPT   Unless required by applicable law or agreed to in writing, software
PROMPT   distributed under the License is distributed on an "AS IS" BASIS,
PROMPT   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
PROMPT   See the License for the specific language governing permissions and
PROMPT   limitations under the License.
PROMPT 
PROMPT 
PROMPT   Copyright (C) 2004-2008 Niels Bertram (niels.bertram@fleurida.com)
PROMPT &line2
PROMPT


PRO &line1
PRO 
PRO Run &install_action for modules &install_module
PRO
PRO &line1

PROMPT [ &txt_prompt ]
@@&install_action
