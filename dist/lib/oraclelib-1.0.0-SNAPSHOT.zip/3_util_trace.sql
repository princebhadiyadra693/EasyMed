PRO
PRO **************************************************************************
PRO Install Trace Utils
PRO
/******************************************************************************

  Installs trace utilities.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/3_util_trace.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

@util/trace/traces.sql

@util/trace/util_trace_ps.sql
@util/trace/util_trace_pb.sql

@3_grants.sql

@3_synonyms.sql

