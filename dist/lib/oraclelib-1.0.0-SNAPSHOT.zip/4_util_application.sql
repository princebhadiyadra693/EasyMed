PRO
PRO **************************************************************************
PRO Install Application Utils
PRO
/******************************************************************************

  Installs application utilities.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/4_util_application.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

-- Exception Management Framework

@util/core/exceptions.sql

@util/core/util_exception_ps.sql
@util/core/util_exception_pb.sql


-- Configuration Framework

@util/conf/property_ts.sql
@util/conf/properties_ts.sql

@util/conf/settings.sql

@util/conf/util_conf_ps.sql
@util/conf/util_conf_pb.sql


-- Logging Framework

@util/logging/log_category.sql

@util/logging/log_appender_type.sql

@util/logging/log_appender.sql


@util/logging/log_appender_abstract_ts.sql
@util/logging/log_appender_abstract_tb.sql

@util/logging/log_appender_console_ts.sql
@util/logging/log_appender_console_tb.sql

@util/logging/log_appender_log4j_ts.sql
@util/logging/log_appender_log4j_tb.sql

@util/logging/util_log_appender_ps.sql
@util/logging/util_log_appender_pb.sql

@util/logging/util_log_ps.sql
@util/logging/util_log_pb.sql

@util/logging/logger_ts.sql
@util/logging/logger_tb.sql

@util/core/stylesheet.sql

@util/email/util_email_ps.sql
@util/email/util_email_pb.sql


@4_grants.sql

@4_synonyms.sql

-- TOOD: only if debug
ALTER PACKAGE util.util_log_appender COMPILE DEBUG PACKAGE
/

ALTER TYPE util.log_appender_abstract COMPILE DEBUG SPECIFICATION
/

ALTER TYPE util.log_appender_abstract COMPILE DEBUG BODY
/

ALTER TYPE util.log_appender_console COMPILE DEBUG SPECIFICATION
/

ALTER TYPE util.log_appender_console COMPILE DEBUG BODY
/

ALTER TYPE util.log_appender_log4j COMPILE DEBUG SPECIFICATION
/

ALTER TYPE util.log_appender_log4j COMPILE DEBUG BODY
/



ALTER PACKAGE util.util_trace COMPILE DEBUG PACKAGE
/

ALTER PACKAGE util.util_exception COMPILE DEBUG PACKAGE
/



ALTER PACKAGE util.util_log COMPILE DEBUG PACKAGE
/

ALTER TYPE util.logger COMPILE DEBUG SPECIFICATION
/

ALTER TYPE util.logger COMPILE DEBUG BODY
/


ALTER PACKAGE util.util_log_appender COMPILE DEBUG PACKAGE
/


ALTER PACKAGE util.util_conf COMPILE DEBUG PACKAGE
/

ALTER PACKAGE util.util_email COMPILE DEBUG PACKAGE
/





-- TODO: move out of the utilitiy into a static data script
-- register all declared/configured exceptions
exec util_exception.register;

-- register at least the root logger
exec util_log.register(util_log.ROOT_LOGGER_NAME, util_log.INFO);

-- first need to register the appender and then add loggers to the root appender
exec util.util_log_appender.register('console', 'util', 'log_appender_console');

exec util.util_log_appender.register('log4j', 'util', 'log_appender_log4j');






-- standard appender that logs to dbms_output
exec util_log_appender.add_appender('root', 'stdout', 'console', util_log.TRACE);

-- an xml appender
--exec util_log_appender.add_appender('root', 'xmlout', 'log4j', util_log.DEBUG);
--exec util_log_appender.add_appender_property('root', 'xmlout', 'log4j.host', 'localhost');
--exec util_log_appender.add_appender_property('root', 'xmlout', 'log4j.port', '4448');

