PRO
PRO **************************************************************************
PRO Run Install
PRO
/******************************************************************************

  Installs the util stack.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/util_install.sql $

  %RunAs:     SYSDBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

-- TODO fail if util already exists 

@1_util_setup.sql
@2_util_core.sql
@3_util_trace.sql
@4_util_application.sql
