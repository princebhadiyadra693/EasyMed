PRO
PRO **************************************************************************
PRO Install Trace Grants
PRO
/******************************************************************************

  Grants various privs on trace util resources.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/3_grants.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

-- used in wrapper PL/SQL package to set session trace level
GRANT EXECUTE ON util.util_trace TO developer
/

-- used by gettrace.sql to display traces captured
GRANT SELECT ON util.traces TO developer
/

