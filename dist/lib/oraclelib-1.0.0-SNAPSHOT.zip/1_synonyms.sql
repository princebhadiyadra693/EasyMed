PRO
PRO **************************************************************************
PRO Install UTIL User Synonyms
PRO
/******************************************************************************

  Creates public synonym for dbms_system if not already (eg. not default in XE).

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/1_synonyms.sql $

  %RunAs:     SYSDBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/
CREATE PUBLIC SYNONYM dbms_system FOR sys.dbms_system
/
