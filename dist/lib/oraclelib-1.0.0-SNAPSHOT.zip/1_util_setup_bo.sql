PRO
PRO **************************************************************************
PRO Remove UTIL User Setup
PRO
/******************************************************************************

  Removes all objects created by 1_util_core install script.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/1_util_setup_bo.sql $

  %RunAs:     DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

DROP ROLE developer CASCADE
/

DROP USER util CASCADE
/

DROP PUBLIC SYNONYM dbms_system
/
