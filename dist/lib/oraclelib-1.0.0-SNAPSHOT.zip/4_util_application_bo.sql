PRO
PRO **************************************************************************
PRO Remove Application Utils
PRO
/******************************************************************************

  Deinstalls application utilities.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/4_util_application_bo.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

/**
 *
 *
 * Logging Framework
 *
 */

-- put back stub for logging framework (stub if not installed in the apps pack)
@util/logging/logger_stub_ts.sql
@util/logging/logger_stub_tb.sql

DROP PUBLIC SYNONYM util_log
/

DROP PACKAGE util.util_log
/

/**
 *
 *
 * Log Appenders
 *
 */

DROP PUBLIC SYNONYM log_appender_console
/

DROP TYPE util.log_appender_console
/

DROP PUBLIC SYNONYM log_appender_log4j
/

DROP TYPE util.log_appender_log4j
/

DROP TYPE util.log_appender_abstract
/


DROP PUBLIC SYNONYM util_log_appender
/

DROP PACKAGE util.util_log_appender
/

DROP TABLE util.log_appender CASCADE CONSTRAINT
/

DROP TABLE util.log_appender_type CASCADE CONSTRAINT
/

DROP TABLE util.log_category CASCADE CONSTRAINT
/

/**
 *
 *
 * Email Utilitiy
 *
 */
DROP PUBLIC SYNONYM util_email
/

DROP PACKAGE util.util_email
/


/**
 *
 *
 * Exception Framework
 *
 */
DROP PUBLIC SYNONYM util_exception
/

DROP PACKAGE util.util_exception
/

DROP TABLE util.exceptions CASCADE CONSTRAINTS
/

/**
 *
 *
 * Configuration Framework
 *
 */
DROP PUBLIC SYNONYM util_conf
/

DROP PACKAGE util.util_conf
/

DROP TABLE util.settings CASCADE CONSTRAINTS
/

DROP PUBLIC SYNONYM Properties
/

DROP TYPE util.Properties FORCE
/

DROP PUBLIC SYNONYM Property
/

DROP TYPE util.Property FORCE
/


/**
 *
 *
 * ??
 *
 */
DROP TABLE util.stylesheet
/