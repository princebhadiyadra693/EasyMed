PRO
PRO **************************************************************************
PRO Install Core Utils
PRO
/******************************************************************************

  Installs core utilities to assist in string, xml or lob manipulation etc.

  All generally usefull utilities are exposed publicly with a public synonym
  and relevant privileges granted to public.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/2_util_core.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/
-- logging framework (stub if not installed in the apps pack)
@util/logging/logger_stub_ts.sql
@util/logging/logger_stub_tb.sql

-- simple locale
@util/core/util_locale_ps.sql
@util/core/util_locale_pb.sql

-- lob utils
@util/string/util_lob_ps.sql
@util/string/util_lob_pb.sql

-- date time utils
@util/datetime/util_temporale_ps.sql
@util/datetime/util_temporale_pb.sql

-- string utils
@util/string/util_string_ps.sql
@util/string/util_string_pb.sql

@util/string/util_sprintf.sql

-- xml utils
@util/xml/util_xml_ps.sql
@util/xml/util_xml_pb.sql

-- concatenation utils

/*

  Aggregation functionality objects.

  Expression Filter (value, delimiter)
    t_aggexp

  String Aggregation Functions
    aggstr
    aggstr_exp
    aggstr_distinct
    aggstr_distinct_exp
    aggclob
    aggclob_exp

  String Aggregation Types (used by the string functions)
    t_aggstr
    t_aggstr_exp
    t_aggstr_distinct
    t_aggstr_distinct_exp
    t_aggclob
    t_aggclob_exp

*/

@util/string/t_arr_varchar2.sql

@util/string/t_aggexp.sql

@util/string/t_aggstr.sql
@util/string/t_aggstr_distinct.sql
@util/string/t_aggstr_exp.sql

@util/string/t_aggclob.sql
@util/string/t_aggclob_exp.sql

@util/string/aggstr.sql
@util/string/aggstr_distinct.sql
@util/string/aggstr_exp.sql

@util/string/aggclob.sql
@util/string/aggclob_exp.sql


-- grants ans syns
@2_grants.sql

@2_synonyms.sql

