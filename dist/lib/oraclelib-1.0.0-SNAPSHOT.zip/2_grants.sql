PRO
PRO **************************************************************************
PRO Install Core Grants
PRO
/******************************************************************************

  Grants various privs on core util resources.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/2_grants.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

-- anone should be able to log
GRANT EXECUTE ON util.logger TO PUBLIC
/

GRANT EXECUTE ON util.util_locale TO PUBLIC
/

GRANT EXECUTE ON util.util_lob TO PUBLIC
/

GRANT EXECUTE ON util.util_temporale TO PUBLIC
/

GRANT EXECUTE ON util.util_string TO PUBLIC
/

GRANT EXECUTE ON util.sprintf TO PUBLIC
/

GRANT EXECUTE ON util.util_xml TO PUBLIC
/

-- agg types and functions need to have both execute privs
GRANT EXECUTE ON util.t_aggexp TO PUBLIC
/

GRANT EXECUTE ON util.t_aggstr TO PUBLIC
/

GRANT EXECUTE ON util.t_aggstr_distinct TO PUBLIC
/

GRANT EXECUTE ON util.t_aggstr_exp TO PUBLIC
/

GRANT EXECUTE ON util.t_aggclob TO PUBLIC
/

GRANT EXECUTE ON util.t_aggclob_exp TO PUBLIC
/

GRANT EXECUTE ON util.aggstr TO PUBLIC
/

GRANT EXECUTE ON util.aggstr_distinct TO PUBLIC
/

GRANT EXECUTE ON util.aggstr_exp TO PUBLIC
/

GRANT EXECUTE ON util.aggclob TO PUBLIC
/

GRANT EXECUTE ON util.aggclob_exp TO PUBLIC
/
