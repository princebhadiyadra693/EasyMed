PRO
PRO **************************************************************************
PRO Run Application Reinstall
PRO
/******************************************************************************

  Removes the application stack and reinstalls it after.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/4_reinstall.sql $

  %RunAs:     SYSDBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

@4_util_application_bo.sql
@4_util_application.sql
