PRO
PRO **************************************************************************
PRO Remove Core Utils
PRO
/******************************************************************************

  Deinstalls core utilities.

  %$URL: https://oraclelib.svn.sourceforge.net/svnroot/oraclelib/trunk/src/main/db/2_util_core_bo.sql $

  %RunAs:     UTIL or DBA

  %$Author: niels-bertram $

  %$LastChangedBy: niels-bertram $

  %$Revision: 1 $

******************************************************************************/

-- util package syns
DROP PUBLIC SYNONYM util_lob
/

DROP PUBLIC SYNONYM util_temporale
/

DROP PUBLIC SYNONYM util_string
/

DROP PUBLIC SYNONYM sprintf
/

DROP PUBLIC SYNONYM util_xml
/

DROP PUBLIC SYNONYM util_locale
/

DROP PUBLIC SYNONYM logger
/

-- agg syns
DROP PUBLIC SYNONYM t_aggexp
/

DROP PUBLIC SYNONYM aggstr
/

DROP PUBLIC SYNONYM aggstr_distinct
/

DROP PUBLIC SYNONYM aggstr_exp
/

DROP PUBLIC SYNONYM aggclob
/

DROP PUBLIC SYNONYM aggclob_exp
/


-- general types
DROP TYPE util.t_arr_varchar2
/

DROP TYPE util.logger
/

-- agg functions
DROP FUNCTION util.aggstr
/

DROP FUNCTION util.aggstr_distinct
/

DROP FUNCTION util.aggstr_exp
/

DROP FUNCTION util.aggclob
/

DROP FUNCTION util.aggclob_exp
/

-- agg types
DROP TYPE util.t_aggstr
/

DROP TYPE util.t_aggstr_distinct
/

DROP TYPE util.t_aggstr_exp
/

DROP TYPE util.t_aggclob
/

DROP TYPE util.t_aggclob_exp
/

DROP TYPE util.t_aggexp
/

-- packages
DROP PACKAGE util.util_lob
/

DROP FUNCTION util.sprintf
/

DROP PACKAGE util.util_string
/

DROP PACKAGE util.util_temporale
/

DROP PACKAGE util.util_xml
/

DROP PACKAGE util.util_locale
/
